/* ═══════════════════════════════════════════
   render.js — DOM güncelleme fonksiyonları
   Bağımlılıklar: data.js, state.js, utils.js
   ═══════════════════════════════════════════ */
'use strict';

// ── Header / stats HUD ───────────────────

function renderHeader() {
  document.getElementById('balance-display').textContent = fmtBalance(G.sat);
  document.getElementById('sps-display').textContent = '+' + fmtSps(G.sps);
  renderGemCount();
}

function renderStats() {
  document.getElementById('stat-total').textContent  = fmtBalance(G.total);
  document.getElementById('stat-clicks').textContent = fmt(G.clicks);
  document.getElementById('stat-devices').textContent = G.devices;
  document.getElementById('click-power').textContent = fmt(calcClickPow());

  // Prestij butonu (mine paneldeki sade hali artık kullanılmıyor)
  const gain = calcPrestigeGain();
  const canPres = gain > 0;
  const btn = document.getElementById('prestige-btn');
  if (btn) {
    btn.disabled = !canPres;
    btn.classList.toggle('ready', canPres);
    const gp = document.getElementById('prestige-gain-preview');
    if (gp) gp.textContent = canPres ? '+' + gain + ' Puan' : 'Daha çok kazanç lazım';
  }

  // Modaldaki gösterim
  const totalEl = document.getElementById('prestige-pts-total');
  if (totalEl) {
    totalEl.textContent = G.prestigePoints + ' Puan × %2 = +%' + (G.prestigePoints * 2).toFixed(0) + ' Kâr';
  }
  const runEl = document.getElementById('prestige-run-val');
  if (runEl) runEl.textContent = G.prestigeRuns;

  // İlerleme çubuğu — toplam kazanca göre
  const fill = document.getElementById('prestige-bar-fill');
  const lbl  = document.getElementById('prestige-bar-label');
  if (fill && lbl) {
    const lifeEarn = (G.totalEver || 0) + G.total;
    const tLow  = currentPrestigeThreshold();
    const tHigh = nextPrestigeThreshold();
    const span  = tHigh - tLow;
    const pct = span > 0 ? Math.max(0, Math.min(100, (lifeEarn - tLow) / span * 100)) : 100;
    fill.style.width = pct.toFixed(1) + '%';

    const needed = Math.max(0, tHigh - lifeEarn);
    const curGain = calcPrestigeGain();
    const nextGain = curGain + 1;
    if (canPres) {
      lbl.textContent = `Hazır (+${curGain} Puan)  ·  +${nextGain} için: ${fmtBalance(needed)}`;
    } else {
      lbl.textContent = `İlk puan için: ${fmtBalance(needed)}`;
    }
  }
}

// ── Shop ─────────────────────────────────

function renderShop() {
  const list = document.getElementById('shop-list');
  if (!list) return;
  list.innerHTML = '';

  const mode = G.buyMode;
  const achBonus = calcAchievBonus();
  const presBonus = calcPrestigeBonus();
  const allBonus = G.allMult * achBonus * presBonus;

  // ── Mutfak ekipmanları başlığı ──
  for (const m of MINERS) {
    const owned = G.miners[m.id] || 0;
    const qty = mode === 0 ? calcMaxBuy(m) : mode;
    const price = qty > 0 ? calcBulkPrice(m, qty) : getMinerPrice(m);
    const afford = qty > 0 && G.sat >= price;
    const qtyLabel = mode === 0 ? 'Maks×' + qty : '×' + mode;

    // Tek bir ekipmanın bonusla birlikte SPS'i
    const spsEach = m.baseSps * allBonus;
    const spsText = spsEach >= 1
      ? fmt(spsEach) + ' $/sn (Adet)'
      : spsEach.toFixed(2) + ' $/sn (Adet)';
    const spsTotal = spsEach * owned;
    const spsTotalText = owned > 0
      ? (spsTotal >= 1 ? fmt(spsTotal) : spsTotal.toFixed(2)) + ' $/sn (Toplam)'
      : null;

    const card = document.createElement('div');
    card.className = 'item-card' + (afford ? ' affordable' : '');
    card.innerHTML =
      `<div class="item-emoji">${m.emoji}</div>` +
      `<div class="item-info">` +
        `<div class="item-name">${m.name}</div>` +
        `<div class="item-desc">${m.desc}</div>` +
        `<div class="item-sps">+${spsText}</div>` +
        (spsTotalText ? `<div class="item-sps-total">= +${spsTotalText}</div>` : '') +
      `</div>` +
      `<div class="item-right">` +
        `<div class="item-price">${fmt(price)} $</div>` +
        `<div class="item-buy-qty">${qtyLabel}</div>` +
        `<div class="item-count">${owned}</div>` +
      `</div>`;
    card.addEventListener('click', () => buyMiner(m));
    list.appendChild(card);
  }

  // ── Personel bölümü ───────────────────
  const mgrdiv = document.createElement('div');
  mgrdiv.className = 'section-title manager-title';
  mgrdiv.textContent = '👤 Personel (Otomatik Tıklama)';
  list.appendChild(mgrdiv);

  for (const m of MANAGERS) {
    const owned = G.managers[m.id] || 0;
    const qty = mode === 0 ? calcManagerMaxBuy(m) : mode;
    const price = qty > 0 ? calcManagerBulkPrice(m, qty) : getManagerPrice(m);
    const afford = qty > 0 && G.sat >= price;
    const qtyLabel = mode === 0 ? 'Maks×' + qty : '×' + mode;
    const cps = m.clicksPerSec.toFixed(1);
    // Doğru hesap: tıklama gücü × cps × adet = $/sn
    const cpsTotal = owned > 0 ? (m.clicksPerSec * calcClickPow() * owned) : 0;

    const card = document.createElement('div');
    card.className = 'item-card manager-card' + (afford ? ' affordable' : '');
    card.innerHTML =
      `<div class="item-emoji">${m.emoji}</div>` +
      `<div class="item-info">` +
        `<div class="item-name">${m.name}</div>` +
        `<div class="item-desc">${m.desc}</div>` +
        `<div class="item-sps">+${cps} Tık/sn</div>` +
        (owned > 0 ? `<div class="item-sps-total">= +${fmt(cpsTotal)} $/sn (Toplam)</div>` : '') +
      `</div>` +
      `<div class="item-right">` +
        `<div class="item-price">${fmt(price)} $</div>` +
        `<div class="item-buy-qty">${qtyLabel}</div>` +
        `<div class="item-count">${owned}</div>` +
      `</div>`;
    card.addEventListener('click', () => buyManager(m));
    list.appendChild(card);
  }

  // Shop badge'i güncelle
  updateShopBadge();
}

/** Hafif badge güncellemesi — her tick'te çağrılır */
function updateShopBadge() {
  const badge = document.getElementById('shop-badge');
  if (!badge) return;
  let count = 0;
  for (const m of MINERS)   if (G.sat >= getMinerPrice(m)) count++;
  for (const m of MANAGERS) if (G.sat >= getManagerPrice(m)) count++;
  badge.textContent = count > 99 ? '99+' : count;
  badge.style.display = count > 0 ? 'block' : 'none';
}

// ── Boost ─────────────────────────────────

function renderBoost() {
  const coinWrap = document.getElementById('coin-wrap');
  const status   = document.getElementById('boost-status');
  const appEl    = document.getElementById('app');
  const now = Date.now();
  const active = G.boostActive && now < G.boostEndsAt;

  if (coinWrap) coinWrap.classList.toggle('boost-active', active);
  if (appEl)    appEl.classList.toggle('boost-active', active);

  if (active) {
    const rem = Math.ceil((G.boostEndsAt - now) / 1000);
    if (status) {
      const mult = G.boostMult || 2;
      status.textContent = `⚡ Yoğunluk x${mult}: ${rem}sn`;
      status.style.visibility = 'visible';
    }
  } else {
    if (G.boostActive) G.boostActive = false;
    if (status) status.style.visibility = 'hidden';
  }
}

// ── Elmas sayacı ──────────────────────────

function renderGemCount() {
  const el  = document.getElementById('gem-count');
  const el2 = document.getElementById('gem-modal-count');
  const gems = G.gems || 0;
  if (el)  el.textContent  = gems;
  if (el2) el2.textContent = gems;
}

// ── Elmas mağazası ────────────────────────

function renderGemShop() {
  const list = document.getElementById('gems-list');
  if (!list) return;
  list.innerHTML = '';
  renderGemCount();

  for (const u of GEM_UPGRADES) {
    const owned = !!(G.gemUpgrades && G.gemUpgrades[u.id]);
    const reqMet = !u.requires || !!(G.gemUpgrades && G.gemUpgrades[u.requires]);
    const canAfford = (G.gems || 0) >= u.cost;

    const card = document.createElement('div');
    card.className = 'gem-card' +
      (owned ? ' gem-owned' : '') +
      (!reqMet ? ' gem-locked' : '') +
      (!owned && reqMet && canAfford ? ' gem-affordable' : '');

    const reqName = u.requires ? (GEM_UPGRADES.find(x => x.id === u.requires) || {}).name : null;

    card.innerHTML =
      `<div class="gem-card-icon">${u.icon}</div>` +
      `<div class="gem-card-info">` +
        `<div class="gem-card-name">${u.name}</div>` +
        `<div class="gem-card-desc">${u.desc}</div>` +
        (reqName && !owned ? `<div class="gem-card-req">🔒 Gerekli: ${reqName}</div>` : '') +
      `</div>` +
      `<div class="gem-card-right">` +
        (owned
          ? `<div class="gem-card-cost owned">✓</div>`
          : `<div class="gem-card-cost">${u.cost} 💎</div>`) +
      `</div>`;

    if (!owned && reqMet) card.addEventListener('click', () => buyGemUpgrade(u));
    list.appendChild(card);
  }

  // ── Bozdurma bölümü ────────────────────────
  const exWrap = document.getElementById('gem-exchange');
  if (!exWrap) return;

  const gems = G.gems || 0;
  const sps  = G.sps || 0;
  const rate = Math.floor(sps * 60); // 1 elmas = 1 dakikalık SPS

  if (gems <= 0 || rate <= 0) {
    exWrap.innerHTML = rate <= 0
      ? '<div class="gem-ex-note">Bozdurma için $/sn ve elmas gerekli</div>'
      : '<div class="gem-ex-note">Bozduracak elmasın yok</div>';
    return;
  }

  const cur = Math.min(parseInt(exWrap.dataset.sliderVal || 1), gems);
  const earn = rate * cur;

  exWrap.innerHTML =
    `<div class="gem-ex-title">🔄 Elmasları Nakde Çevir</div>` +
    `<div class="gem-ex-rate">1 💎 = <b>${fmtBalance(rate)}</b> <span class="gem-ex-hint">(1 dk kazanç)</span></div>` +
    `<div class="gem-ex-qty-row"><span id="gem-ex-qty">${cur} 💎</span><span class="gem-ex-of">/ ${gems}</span></div>` +
    `<div class="gem-ex-row">` +
    `<input type="range" id="gem-ex-slider" min="1" max="${gems}" value="${cur}" />` +
    `</div>` +
    `<div class="gem-ex-preview" id="gem-ex-preview">+${fmtBalance(earn)}</div>` +
    `<button class="gem-ex-btn" id="gem-ex-btn">Bozdur</button>`;

  exWrap.dataset.sliderVal = cur;

  const slider  = document.getElementById('gem-ex-slider');
  const qtyEl   = document.getElementById('gem-ex-qty');
  const preview = document.getElementById('gem-ex-preview');

  function updateSliderFill(val) {
    const pct = gems > 1 ? ((val - 1) / (gems - 1) * 100).toFixed(1) : 100;
    slider.style.background =
      `linear-gradient(90deg, rgba(140,90,255,0.80) ${pct}%, var(--bg5,#2a2040) ${pct}%)`;
  }
  updateSliderFill(cur);

  slider.addEventListener('input', () => {
    const v = parseInt(slider.value);
    exWrap.dataset.sliderVal = v;
    qtyEl.textContent = v + ' 💎';
    preview.textContent = '+' + fmtBalance(rate * v);
    updateSliderFill(v);
  });
  document.getElementById('gem-ex-btn').addEventListener('click', () => {
    const v = parseInt(slider.value);
    const total = rate * v;
    if (G.gems < v) return;
    G.gems -= v;
    G.sat += total;
    G.total += total;
    exWrap.dataset.sliderVal = '1';
    sndCoin();
    spawnFloat(window.innerWidth / 2, window.innerHeight / 2, '+' + fmt(total) + ' $');
    renderHeader();
    renderStats();
    renderGemShop();
    save();
  });
}

// ── Geliştirmeler paneli ──────────────────────

function renderUpgrades() {
  const list = document.getElementById('upgrades-list');
  if (!list) return;
  list.innerHTML = '';

  const clickUpgrades = UPGRADES.filter(u => u.type === 'click');
  const allUpgrades   = UPGRADES.filter(u => u.type === 'all');

  _appendSectionTitle(list, '🍔 Lezzet ve Mutfak Geliştirmeleri');
  clickUpgrades.forEach(u => list.appendChild(_makeUpgradeCard(u)));

  _appendSectionTitle(list, '📋 Menü ve Pazarlama');
  allUpgrades.forEach(u => list.appendChild(_makeUpgradeCard(u)));

  updateUpgBadge();
}

/** Hafif geliştirme badge güncellemesi */
function updateUpgBadge() {
  const badge = document.getElementById('upg-badge');
  if (!badge) return;
  const avail = UPGRADES.filter(u => !G.upgrades[u.id] && G.sat >= u.price).length;
  badge.textContent = avail;
  badge.style.display = avail > 0 ? 'block' : 'none';
}

function _appendSectionTitle(parent, text) {
  const d = document.createElement('div');
  d.className = 'section-title';
  d.textContent = text;
  parent.appendChild(d);
}

function _makeUpgradeCard(u) {
  const bought = !!G.upgrades[u.id];
  const afford = !bought && G.sat >= u.price;
  const card = document.createElement('div');
  const tagText = u.type === 'click' ? `Tıklama gücü ×${u.mult}` : `Tüm gelir ×${u.mult}`;
  const tagCls = u.type === 'all' ? 'upgrade-tag type-all' : 'upgrade-tag';

  card.className = 'item-card upgrade-card' +
    (bought ? ' bought' : afford ? ' affordable' : '');

  card.innerHTML =
    `<div class="item-emoji">${u.icon}</div>` +
    `<div class="item-info">` +
      `<div class="item-name">${u.name}</div>` +
      `<div class="item-desc">${u.desc}</div>` +
      `<span class="${tagCls}">${tagText}</span>` +
    `</div>` +
    `<div class="item-right">` +
      (bought
        ? `<div class="item-price done">✓</div>`
        : `<div class="item-price">${fmt(u.price)} $</div>`) +
    `</div>`;

  if (!bought) card.addEventListener('click', () => buyUpgrade(u));
  return card;
}

// ── Başarımlar ─────────────────────────

function renderAchievements() {
  const grid = document.getElementById('ach-grid');
  if (!grid) return;
  grid.innerHTML = '';

  let unlocked = 0;
  for (const a of ACHIEVEMENTS) {
    const done = !!G.achiev[a.id];
    if (done) unlocked++;

    const card = document.createElement('div');
    card.className = 'ach-card' + (done ? ' unlocked' : '');
    card.innerHTML =
      `<div class="ach-icon">${a.icon}</div>` +
      `<div class="ach-name">${a.name}</div>` +
      `<div class="ach-desc">${done ? a.desc : '???'}</div>`;
    grid.appendChild(card);
  }

  const total = ACHIEVEMENTS.length;
  const pct = total > 0 ? (unlocked / total * 100).toFixed(0) : 0;
  document.getElementById('ach-bar').style.width = pct + '%';
  document.getElementById('ach-bar-label').textContent =
    `${unlocked} / ${total}  ·  +%${unlocked} kalıcı bonus`;

  // Badge: yeni başarımlar varsa göster (yarı zaman)
  const badge = document.getElementById('ach-badge');
  if (badge) badge.style.display = 'none'; // şimdilik kapalı
}

// ── İstatistikler ─────────────────────

function renderStatPanel() {
  const list = document.getElementById('stats-list');
  if (!list) return;

  const achCount = Object.keys(G.achiev).length;
  const topMiner = MINERS.reduce((best, m) => {
    const contrib = m.baseSps * (G.miners[m.id] || 0);
    return contrib > best.val ? { val: contrib, name: m.name, emoji: m.emoji } : best;
  }, { val: 0, name: '—', emoji: '' });

  const sections = [
    {
      title: '💰 Kasa Durumu',
      rows: [
        ['Tüm Zamanların Kazancı', fmtBalance(G.totalEver + G.total)],
        ['Anlık $/sn',             fmtSps(G.sps)],
        ['En Yüksek $/sn',         fmtSps(G.spsRecord)],
        ['Toplam Tıklama',         fmt(G.clicks)],
        ['Otomatik $/sn',          fmt(Math.round(calcAutoClick()))],
      ]
    },
    {
      title: '🚚 Şube Yönetimi',
      rows: [
        ['Toplam Şube Sayısı',         G.prestigeRuns],
        ['Biriken Puan',               G.prestigePoints],
        ['Kâr Bonusu',                 '+%' + (G.prestigePoints * 2).toFixed(0)],
        ['En İyi Şube Açılışı (Puan)', G.bestPrestigeGain > 0 ? '+' + G.bestPrestigeGain : '—'],
      ]
    },
    {
      title: '🍟 Dükkan İstatistikleri',
      rows: [
        ['Mevcut Ekipmanlar',          G.devices],
        ['Tüm Zamanlarda Alınanlar',   G.totalDevicesEver + G.devices],
        ['Yapılan Geliştirmeler',      G.upgCount + ' / ' + UPGRADES.length],
        ['En Kârlı Ekipman',           topMiner.val > 0 ? topMiner.emoji + ' ' + topMiner.name : '—'],
      ]
    },
    {
      title: '🏅 Kariyer Özeti',
      rows: [
        ['Kazanılan Başarılar',  achCount + ' / ' + ACHIEVEMENTS.length],
        ['Başarım Bonusu',       '+%' + achCount + ' SPS'],
        ['Toplam Elmas',         (G.gemsEverEarned || 0) + ' 💎'],
        ['Yakalanan Altın',      (G.goldenCaught || 0) + ' ⭐'],
        ['Giriş Serisi',         (G.loginStreak || 0) + ' gün'],
        ['Oyunda Geçen Süre',    fmtTime(G.playtime)],
      ]
    },
  ];

  list.innerHTML = sections.map(sec => `
    <div class="stat-section">
      <div class="section-title">${sec.title}</div>
      ${sec.rows.map(([k, v]) =>
        `<div class="stat-row"><span class="stat-key">${k}</span><span class="stat-val">${v}</span></div>`
      ).join('')}
    </div>
  `).join('') +
  `<div class="stat-section">
    <div class="section-title">⚙️ Ayarlar</div>
    <div class="stat-row">
      <span class="stat-key">Ses</span>
      <button id="settings-sound" class="stat-toggle">${isSoundEnabled() ? 'Açık 🔊' : 'Kapalı 🔇'}</button>
    </div>
    <div class="stat-row">
      <span class="stat-key">Titreşim</span>
      <button id="settings-vibe" class="stat-toggle">${isVibeEnabled() ? 'Açık 📳' : 'Kapalı'}</button>
    </div>
    <div class="stat-row">
      <span class="stat-key">İflas Et (Tüm Veriyi Sil)</span>
      <button id="settings-reset" class="stat-toggle danger">Sıfırla 🧨</button>
    </div>
  </div>`;

  // Ayar butonlarını bağla
  const sb = document.getElementById('settings-sound');
  if (sb) sb.addEventListener('click', () => {
    setSoundEnabled(!isSoundEnabled());
    sndClick();
    renderStatPanel();
  });
  const vb = document.getElementById('settings-vibe');
  if (vb) vb.addEventListener('click', () => {
    setVibeEnabled(!isVibeEnabled());
    vibe(40);
    renderStatPanel();
  });
  const rb = document.getElementById('settings-reset');
  if (rb) rb.addEventListener('click', () => window.resetGame());
}

// ── Frenzy çarpan göstergesi ───────────────

function renderFrenzy() {
  const pct = Math.round(G.clickFrenzy);
  const chip = document.getElementById('frenzy-chip');
  if (!chip) return;
  if (pct > 0) {
    chip.textContent = '🔥 +' + pct + '%';
    chip.style.display = 'inline-block';
  } else {
    chip.style.display = 'none';
  }
}

// ── Float text (tıklama efektleri) ────────────

function spawnFloat(cx, cy, text) {
  const app = document.getElementById('app');
  if (!app) return;
  const rect = app.getBoundingClientRect();
  const lx = cx - rect.left;
  const ly = cy - rect.top;

  // Frenzy seviyesine göre renk
  const pct = Math.round(G.clickFrenzy);
  const color = pct >= 80 ? '#ff6a00'
              : pct >= 50 ? '#f7931a'
              : pct >= 20 ? '#ffc15e'
              : 'var(--green)';

  // Yükselen yazı
  const el = document.createElement('div');
  el.className = 'float-text';
  el.textContent = text;
  el.style.color = color;
  const ox = (Math.random() * 40) - 20;
  el.style.left = (lx + ox - 20) + 'px';
  el.style.top  = (ly - 16) + 'px';
  app.appendChild(el);
  setTimeout(() => el.remove(), 950);

  // Spark parçacıkları
  const sparkCount = 5 + Math.floor(pct / 25); // 5-9 spark
  for (let i = 0; i < sparkCount; i++) {
    const angle = (Math.PI * 2 / sparkCount) * i + Math.random() * 0.6;
    const dist = 28 + Math.random() * 22;
    const s = document.createElement('div');
    s.className = 'spark';
    s.style.background = color;
    s.style.boxShadow = '0 0 4px ' + color;
    s.style.left = (lx - 3) + 'px';
    s.style.top  = (ly - 3) + 'px';
    s.style.setProperty('--tx', (Math.cos(angle) * dist).toFixed(1) + 'px');
    s.style.setProperty('--ty', (Math.sin(angle) * dist).toFixed(1) + 'px');
    s.style.setProperty('--dur', (0.4 + Math.random() * 0.25) + 's');
    app.appendChild(s);
    setTimeout(() => s.remove(), 700);
  }

  // Ripple
  const coinWrap = document.getElementById('coin-wrap');
  if (coinWrap) {
    const ripple = document.createElement('div');
    ripple.className = 'coin-ripple';
    coinWrap.appendChild(ripple);
    setTimeout(() => ripple.remove(), 580);
  }
}

/** Otomatik tıklama için yumuşak float text */
function spawnAutoFloat(cx, cy, text) {
  const app = document.getElementById('app');
  if (!app) return;
  const rect = app.getBoundingClientRect();
  const el = document.createElement('div');
  el.className = 'float-text auto-float';
  el.textContent = text;
  const ox = (Math.random() * 50) - 25;
  el.style.left = (cx - rect.left + ox - 20) + 'px';
  el.style.top  = (cy - rect.top - 30 + Math.random() * 20 - 10) + 'px';
  app.appendChild(el);
  setTimeout(() => el.remove(), 900);
}
