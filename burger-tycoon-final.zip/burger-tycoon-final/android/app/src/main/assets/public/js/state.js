/* ═══════════════════════════════════════════
   state.js — Oyun Hafızası, Kayıt Sistemi ve Matematik
   Burger Tycoon
   ═══════════════════════════════════════════ */
'use strict';

const SAVE_KEY = 'burger_tycoon_v2'; // v2: yeni alanlar (loginStreak, gemsEverEarned, daily)

const G = {
  // ─ Para ve sayılar ─
  sat:            0,
  total:          0,
  clicks:         0,
  devices:        0,
  sps:            0,
  playtime:       0,
  upgCount:       0,

  // ─ Sahip olunan eşyalar ─
  miners:         {},
  upgrades:       {},
  achiev:         {},
  managers:       {},
  gemUpgrades:    {},

  // ─ Çarpanlar ─
  clickMult:      1,
  allMult:        1,

  // ─ Prestij ─
  prestigePoints: 0,
  prestigeRuns:   0,

  // ─ UI durumu ─
  buyMode:        1,
  clickFrenzy:    0,

  // ─ Boost ─
  boostActive:    false,
  boostEndsAt:    0,
  boostMult:      2, // 2x veya 6x (gem upgrade ile)

  // ─ Elmas ─
  gems:           0,
  gemsEverEarned: 0,

  // ─ Reklam ─
  noAds:          false,

  // ─ Tüm zamanlar istatistikleri ─
  totalEver:        0,
  totalDevicesEver: 0,
  spsRecord:        0,
  bestPrestigeGain: 0,
  goldenCaught:     0,

  // ─ Daily reward ─
  loginStreak:    0,
  lastClaimDate:  '', // 'YYYY-MM-DD'

  // ─ Tutorial ─
  tutorialDone:   false,
};

// ── Fiyat hesaplamaları ─────────────────────────────

function getMinerPrice(m) {
  const owned = G.miners[m.id] || 0;
  return Math.ceil(m.basePrice * Math.pow(1.15, owned));
}

function getManagerPrice(m) {
  const owned = G.managers[m.id] || 0;
  return Math.ceil(m.basePrice * Math.pow(1.15, owned));
}

function calcBulkPrice(m, qty) {
  const owned = G.miners[m.id] || 0;
  let total = 0;
  for (let i = 0; i < qty; i++) {
    total += Math.ceil(m.basePrice * Math.pow(1.15, owned + i));
  }
  return total;
}

function calcMaxBuy(m) {
  let qty = 0, total = 0;
  const owned = G.miners[m.id] || 0;
  while (qty < 10000) {
    const next = Math.ceil(m.basePrice * Math.pow(1.15, owned + qty));
    if (total + next > G.sat) break;
    total += next;
    qty++;
  }
  return qty;
}

function calcManagerBulkPrice(m, qty) {
  const owned = G.managers[m.id] || 0;
  let total = 0;
  for (let i = 0; i < qty; i++) {
    total += Math.ceil(m.basePrice * Math.pow(1.15, owned + i));
  }
  return total;
}

function calcManagerMaxBuy(m) {
  let qty = 0, total = 0;
  const owned = G.managers[m.id] || 0;
  while (qty < 10000) {
    const next = Math.ceil(m.basePrice * Math.pow(1.15, owned + qty));
    if (total + next > G.sat) break;
    total += next;
    qty++;
  }
  return qty;
}

// ── SPS / tıklama gücü hesaplamaları ────────────────

/** Başarımlardan kazanılan kalıcı bonus: kazanılan başarım başına +%1 SPS */
function calcAchievBonus() {
  const count = Object.keys(G.achiev || {}).length;
  return 1 + count * 0.01;
}

function calcSps() {
  let s = 0;
  for (const m of MINERS) s += m.baseSps * (G.miners[m.id] || 0);
  const boost = G.boostActive && Date.now() < G.boostEndsAt ? (G.boostMult || 2) : 1;
  return s * G.allMult * calcPrestigeBonus() * calcAchievBonus() * boost;
}

function calcClickPow() {
  const boost = G.boostActive && Date.now() < G.boostEndsAt ? (G.boostMult || 2) : 1;
  return Math.max(1, Math.floor(G.clickMult * boost));
}

/** Otomatik tıklama: personellerin saniye başına gelir katkısı */
function calcAutoClick() {
  let cps = 0;
  for (const m of MANAGERS) cps += m.clicksPerSec * (G.managers[m.id] || 0);
  return cps * calcClickPow();
}

// ── Boost ───────────────────────────────────────────

function activateBoost() {
  G.boostActive = true;
  G.boostEndsAt = Date.now() + calcBoostDuration() * 1000;
  // boost_gem2 → 3x; boost_gem var ama 2 yoksa → 2x
  G.boostMult = G.gemUpgrades['boost_gem2'] ? 3 : 2;
  save();
}

function calcBoostDuration() {
  return G.gemUpgrades['boost_gem'] ? 45 : 30;
}

// ── Prestij ─────────────────────────────────────────

function calcPrestigeBonus() {
  return 1 + G.prestigePoints * 0.02;
}

function calcPrestigeGain() {
  // Toplam kazanç bazlı (anlık SPS değil — daha tutarlı)
  // formula: floor(sqrt(totalLifeTimeEarn / 1e9) * 5)
  const lifeEarn = (G.totalEver || 0) + G.total;
  const base = Math.floor(Math.sqrt(lifeEarn / 1e9) * 5);
  return base <= 0 ? 0 : base;
}

/** Bir sonraki puan için gereken toplam kazanç miktarı */
function nextPrestigeThreshold() {
  const cur = calcPrestigeGain();
  const next = cur + 1;
  return Math.pow(next / 5, 2) * 1e9;
}

function currentPrestigeThreshold() {
  const cur = calcPrestigeGain();
  return Math.pow(cur / 5, 2) * 1e9;
}

// ── Offline süre ────────────────────────────────────

function calcOfflineMax() {
  if (G.gemUpgrades['offline48h']) return 172800; // 48s
  if (G.gemUpgrades['offline12h']) return 43200;  // 12s
  if (G.gemUpgrades['offline4h'])  return 14400;  // 4s
  return 7200; // 2s default
}

// ── Çarpanları yeniden hesapla ──────────────────────

function recalcMults() {
  let cm = 1;
  let am = 1;

  for (const u of UPGRADES) {
    if (G.upgrades[u.id]) {
      if (u.type === 'click') cm *= u.mult;
      else                    am *= u.mult;
    }
  }

  for (const u of GEM_UPGRADES) {
    if (G.gemUpgrades[u.id] && u.type === 'click') cm *= u.mult;
    if (G.gemUpgrades[u.id] && u.type === 'all')   am *= u.mult;
  }

  G.clickMult = cm;
  G.allMult = am;
}

// ── Prestij yapma ───────────────────────────────────

function doPrestige() {
  const gain = calcPrestigeGain();
  if (gain <= 0) return false;

  // Korunan değerler
  const keep = {
    achiev:           G.achiev,
    prestigePoints:   G.prestigePoints + gain,
    prestigeRuns:     G.prestigeRuns + 1,
    playtime:         G.playtime,
    totalEver:        G.totalEver + G.total,
    totalDevicesEver: G.totalDevicesEver + G.devices,
    bestPrestigeGain: Math.max(G.bestPrestigeGain, gain),
    spsRecord:        G.spsRecord,
    gems:             G.gems,
    gemsEverEarned:   G.gemsEverEarned,
    gemUpgrades:      G.gemUpgrades,
    noAds:            G.noAds,
    goldenCaught:     G.goldenCaught,
    loginStreak:      G.loginStreak,
    lastClaimDate:    G.lastClaimDate,
    tutorialDone:     G.tutorialDone,
  };

  // Sıfırla
  G.sat       = 0;
  G.total     = 0;
  G.clicks    = 0;
  G.devices   = 0;
  G.sps       = 0;
  G.upgCount  = 0;
  G.miners    = {};
  G.upgrades  = {};
  G.managers  = {};
  G.clickMult = 1;
  G.allMult   = 1;
  G.boostActive = false;
  G.boostEndsAt = 0;
  G.clickFrenzy = 0;

  // Geri yükle
  Object.assign(G, keep);

  recalcMults();
  save();
  return true;
}

// ── Kayıt / yükleme ─────────────────────────────────

function save() {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify({
      sat:              G.sat,
      total:            G.total,
      clicks:           G.clicks,
      devices:          G.devices,
      playtime:         G.playtime,
      upgCount:         G.upgCount,
      miners:           G.miners,
      upgrades:         G.upgrades,
      achiev:           G.achiev,
      prestigePoints:   G.prestigePoints,
      prestigeRuns:     G.prestigeRuns,
      totalEver:        G.totalEver,
      totalDevicesEver: G.totalDevicesEver,
      spsRecord:        G.spsRecord,
      bestPrestigeGain: G.bestPrestigeGain,
      managers:         G.managers,
      gems:             G.gems,
      gemsEverEarned:   G.gemsEverEarned,
      gemUpgrades:      G.gemUpgrades,
      noAds:            G.noAds,
      goldenCaught:     G.goldenCaught,
      loginStreak:      G.loginStreak,
      lastClaimDate:    G.lastClaimDate,
      tutorialDone:     G.tutorialDone,
      lastSeen:         Date.now()
    }));
  } catch (err) {
    console.warn('Kayıt hatası:', err);
  }
}

function load() {
  try {
    // Önce yeni anahtardan yüklemeyi dene; yoksa eski v1'den geçiş yap
    let raw = localStorage.getItem(SAVE_KEY);
    if (!raw) {
      const old = localStorage.getItem('burger_tycoon_v1');
      if (old) {
        raw = old;
        localStorage.setItem(SAVE_KEY, old);
      }
    }
    const d = JSON.parse(raw || '{}');

    // Sayısal değerler
    if (d.sat              != null) G.sat              = Number(d.sat) || 0;
    if (d.total            != null) G.total            = Number(d.total) || 0;
    if (d.clicks           != null) G.clicks           = Number(d.clicks) || 0;
    if (d.devices          != null) G.devices          = Number(d.devices) || 0;
    if (d.playtime         != null) G.playtime         = Number(d.playtime) || 0;
    if (d.upgCount         != null) G.upgCount         = Number(d.upgCount) || 0;
    if (d.prestigePoints   != null) G.prestigePoints   = Number(d.prestigePoints) || 0;
    if (d.prestigeRuns     != null) G.prestigeRuns     = Number(d.prestigeRuns) || 0;
    if (d.totalEver        != null) G.totalEver        = Number(d.totalEver) || 0;
    if (d.totalDevicesEver != null) G.totalDevicesEver = Number(d.totalDevicesEver) || 0;
    if (d.spsRecord        != null) G.spsRecord        = Number(d.spsRecord) || 0;
    if (d.bestPrestigeGain != null) G.bestPrestigeGain = Number(d.bestPrestigeGain) || 0;
    if (d.gems             != null) G.gems             = Number(d.gems) || 0;
    if (d.gemsEverEarned   != null) G.gemsEverEarned   = Number(d.gemsEverEarned) || 0;
    if (d.goldenCaught     != null) G.goldenCaught     = Number(d.goldenCaught) || 0;
    if (d.loginStreak      != null) G.loginStreak      = Number(d.loginStreak) || 0;
    if (d.noAds            != null) G.noAds            = !!d.noAds;
    if (d.tutorialDone     != null) G.tutorialDone     = !!d.tutorialDone;
    if (d.lastClaimDate    != null) G.lastClaimDate    = String(d.lastClaimDate);

    // Objeler
    if (d.miners      && typeof d.miners      === 'object') G.miners      = d.miners;
    if (d.upgrades    && typeof d.upgrades    === 'object') G.upgrades    = d.upgrades;
    if (d.achiev      && typeof d.achiev      === 'object') G.achiev      = d.achiev;
    if (d.managers    && typeof d.managers    === 'object') G.managers    = d.managers;
    if (d.gemUpgrades && typeof d.gemUpgrades === 'object') G.gemUpgrades = d.gemUpgrades;

    return d.lastSeen ? Math.min((Date.now() - d.lastSeen) / 1000, calcOfflineMax()) : 0;
  } catch (err) {
    console.warn('Yükleme hatası:', err);
    return 0;
  }
}

// ── Sayfadan ayrılırken kaydet ──────────────────────

window.addEventListener('beforeunload', save);
window.addEventListener('pagehide', save);

document.addEventListener('visibilitychange', () => {
  if (document.hidden) save();
});
