/* ═══════════════════════════════════════════
   utils.js — Yardımcı fonksiyonlar (format, ses, titreşim)
   ═══════════════════════════════════════════ */
'use strict';

// ── Sayı Formatı ───────────────────────────────────

/**
 * Büyük sayıları kısa, okunabilir bir biçimde gösterir.
 * Örn: 1 500 000 → "1.50M"
 */
function fmt(n) {
  if (!isFinite(n) || n < 0) return '0';
  if (n < 1e3)  return n % 1 === 0 ? n.toFixed(0) : n.toFixed(1);
  if (n < 1e6)  return (n / 1e3).toFixed(2)  + 'K';
  if (n < 1e9)  return (n / 1e6).toFixed(2)  + 'M';
  if (n < 1e12) return (n / 1e9).toFixed(2)  + 'B';
  if (n < 1e15) return (n / 1e12).toFixed(2) + 'T';
  if (n < 1e18) return (n / 1e15).toFixed(2) + 'Qa';
  if (n < 1e21) return (n / 1e18).toFixed(2) + 'Qi';
  if (n < 1e24) return (n / 1e21).toFixed(2) + 'Sx';
  if (n < 1e27) return (n / 1e24).toFixed(2) + 'Sp';
  if (n < 1e30) return (n / 1e27).toFixed(2) + 'Oc';
  return (n / 1e30).toFixed(2) + 'No';
}

/** Para göstergesi: "1.50M $" */
function fmtBalance(n) {
  return fmt(n) + ' $';
}

/** Saniye başına gelir göstergesi */
function fmtSps(n) {
  return fmt(n) + ' $/sn';
}

/** Geçen saniyeyi HH:MM:SS biçiminde göster */
function fmtTime(totalSeconds) {
  const s = Math.floor(totalSeconds);
  const h  = Math.floor(s / 3600).toString().padStart(2, '0');
  const m  = Math.floor((s % 3600) / 60).toString().padStart(2, '0');
  const ss = (s % 60).toString().padStart(2, '0');
  return `${h}:${m}:${ss}`;
}

/** YYYY-MM-DD biçiminde bugünün tarihi (yerel saat dilimi) */
function todayStr() {
  const d = new Date();
  const y = d.getFullYear();
  const m = (d.getMonth() + 1).toString().padStart(2, '0');
  const day = d.getDate().toString().padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/** Bir tarihten sonraki gün (YYYY-MM-DD) */
function dayAfter(yyyymmdd) {
  if (!yyyymmdd) return '';
  const [y, m, d] = yyyymmdd.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + 1);
  const ny = dt.getFullYear();
  const nm = (dt.getMonth() + 1).toString().padStart(2, '0');
  const nd = dt.getDate().toString().padStart(2, '0');
  return `${ny}-${nm}-${nd}`;
}

// ── Ses (Web Audio API ile, dosya gerektirmez) ─────

let _audioCtx = null;
let _soundEnabled = (localStorage.getItem('btc_sound') !== '0'); // varsayılan açık

function isSoundEnabled() { return _soundEnabled; }
function setSoundEnabled(v) {
  _soundEnabled = !!v;
  localStorage.setItem('btc_sound', _soundEnabled ? '1' : '0');
}

function _audioCtxLazy() {
  if (_audioCtx) return _audioCtx;
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return null;
    _audioCtx = new Ctx();
  } catch (e) { return null; }
  return _audioCtx;
}

/**
 * Kısa bir bip sesi çalar.
 * @param {number} freq Hz cinsinden frekans
 * @param {number} dur saniye
 * @param {number} vol 0..1
 * @param {string} type 'sine'|'square'|'triangle'|'sawtooth'
 */
function playTone(freq, dur = 0.05, vol = 0.05, type = 'sine') {
  if (!_soundEnabled) return;
  const ctx = _audioCtxLazy();
  if (!ctx) return;
  // iOS'ta context'i kullanıcı etkileşiminden sonra resume etmek gerek
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  try {
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.value = 0;
    g.gain.linearRampToValueAtTime(vol, ctx.currentTime + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    o.connect(g).connect(ctx.destination);
    o.start();
    o.stop(ctx.currentTime + dur + 0.02);
  } catch (e) { /* sessizce yok say */ }
}

function sndClick()    { playTone(620 + Math.random() * 80, 0.04, 0.04, 'square'); }
function sndBuy()      { playTone(440, 0.07, 0.06, 'triangle'); setTimeout(() => playTone(660, 0.09, 0.06, 'triangle'), 60); }
function sndError()    { playTone(180, 0.12, 0.06, 'sawtooth'); }
function sndAch()      { playTone(660, 0.09, 0.07, 'triangle'); setTimeout(() => playTone(880, 0.12, 0.07, 'triangle'), 90); setTimeout(() => playTone(1100, 0.16, 0.07, 'triangle'), 200); }
function sndCoin()     { playTone(880, 0.05, 0.05, 'sine'); setTimeout(() => playTone(1320, 0.08, 0.05, 'sine'), 40); }
function sndGem()      { playTone(1200, 0.12, 0.07, 'sine'); setTimeout(() => playTone(1800, 0.15, 0.05, 'sine'), 80); }
function sndBoost()    { playTone(330, 0.08, 0.07, 'sawtooth'); setTimeout(() => playTone(660, 0.12, 0.07, 'sawtooth'), 80); setTimeout(() => playTone(990, 0.18, 0.07, 'sawtooth'), 180); }
function sndPrestige() { playTone(523, 0.16, 0.08, 'triangle'); setTimeout(() => playTone(659, 0.16, 0.08, 'triangle'), 150); setTimeout(() => playTone(784, 0.20, 0.08, 'triangle'), 300); setTimeout(() => playTone(1047, 0.30, 0.08, 'triangle'), 480); }

// ── Titreşim ───────────────────────────────────────

let _vibeEnabled = (localStorage.getItem('btc_vibe') !== '0'); // varsayılan açık

function isVibeEnabled() { return _vibeEnabled; }
function setVibeEnabled(v) {
  _vibeEnabled = !!v;
  localStorage.setItem('btc_vibe', _vibeEnabled ? '1' : '0');
}

function vibe(ms) {
  if (!_vibeEnabled) return;
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    try { navigator.vibrate(ms); } catch (e) { /* yok say */ }
  }
}
