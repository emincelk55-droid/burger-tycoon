/* ═══════════════════════════════════════════
   data.js — Oyun Sabitleri (Burger Tycoon)
   Ekipmanlar, geliştirmeler, başarımlar, personel
   ═══════════════════════════════════════════ */
'use strict';

/**
 * Mutfak Ekipmanları (otomatik gelir kaynakları)
 * Cookie Clicker mantığı: x10 başına ortalama maliyet,
 * baseSps:basePrice oranı her seviyede ~%5-15 daha verimli
 */
const MINERS = (() => {
  const m = (id, name, emoji, price, sps, desc) => ({
    id, name, emoji, desc,
    basePrice: price,
    baseSps: sps,
  });
  return [
    m('calculator', 'Eski Izgara',           '🍳',      15,        0.1,        'Çok yavaş ama köfte pişiriyor'),
    m('smartphone', 'Stajyer Aşçı',          '👨‍🍳',     100,        1,          'Sürekli telefona bakıyor ama fena değil'),
    m('tablet',     'Sanayi Tipi Fritöz',    '🍟',      1_100,      8,          'Patatesleri saniyeler içinde altın sarısı yapar'),
    m('laptop',     'Profesyonel Ocak',      '♨️',      12_000,     47,         'Aynı anda 20 burger pişirme kapasitesi'),
    m('pc',         'İçecek Makinesi',       '🥤',      130_000,    260,        'Buzlu kolalar paraları su gibi akıtıyor'),
    m('rig',        'Drive-Thru Penceresi',  '🚗',      1_400_000,  1_400,      'Arabaya servis ile hızınıza hız katın'),
    m('asic',       'Yemek Sepeti Motoru',   '🛵',      20_000_000, 7_800,      'Tüm mahalleye jet hızıyla paket servis'),
    m('garage',     'Mahalle Dükkanı',       '🏪',      330_000_000,44_000,     'Kendi küçük mekanın, daimi müşteriler'),
    m('container',  'AVM Standı',            '🏬',      5.1e9,      260_000,    'Hafta sonu kalabalığı = Nakit fırtınası'),
    m('datacenter', 'Lüks Restoran',         '🍽️',     7.5e10,     1_600_000,  'Valeli, garsonlu, pahalı menülü elit mekan'),
    m('hydro',      'Şehir Merkezi Şubesi',  '🏙️',     1.0e12,     10_000_000, 'Meydanın en işlek yerinde para basan şube'),
    m('orbit',      'Uluslararası Zincir',   '🌍',      1.4e13,     65_000_000, 'Artık küresel bir marka oldun'),
    m('quantum',    'Moleküler Gastronomi',  '🔬',      2.0e14,     430_000_000,'Zenginler için mikroskobik ama pahalı burgerler'),
    m('dyson',      'Galaktik Burger',       '🌌',      3.3e15,     2.9e9,      'Tüm evreni doyuracak kapasiteye ulaştın'),
    m('multiverse', 'Çoklu Evren Zinciri',   '🌠',      5.1e16,     2.1e10,     'Paralel evrenlerde de aynı menü, aynı fiyat'),
  ];
})();

/**
 * Geliştirmeler — bir defalık satın alımlar
 * click: tıklama gücünü çarpar
 * all:   tüm SPS'i çarpar
 */
const UPGRADES = [
  // ─ Tıklama Geliştirmeleri ─
  { id: 'sw1',     name: 'Gizli Sos',         desc: 'Burgerleri lezzetlendirir, daha çok satarsın',  price: 250,         mult: 2,  type: 'click', icon: '🥫' },
  { id: 'sw2',     name: 'Çıtır Ekmekler',    desc: 'Müşteriler bu ekmeğe bayılıyor',                price: 5_000,       mult: 2,  type: 'click', icon: '🥖' },
  { id: 'mem',     name: 'Kaliteli Et',       desc: 'Daha iyi et, daha yüksek fiyat',                price: 50_000,      mult: 3,  type: 'click', icon: '🥩' },
  { id: 'oc',      name: 'Çift Köfte',        desc: 'Doyurucu porsiyonlarla kazancı katla',          price: 400_000,     mult: 5,  type: 'click', icon: '🍔' },
  { id: 'asicclk', name: 'Şef Bıçağı',        desc: 'Malzemeleri ışık hızında doğra',                price: 5_000_000,   mult: 8,  type: 'click', icon: '🔪' },
  { id: 'qclk',    name: '3D Burger Yazıcı',  desc: 'Teknoloji ile anında üretim',                   price: 1.2e8,       mult: 15, type: 'click', icon: '🖨️' },
  { id: 'ultra',   name: 'Efsanevi Lezzet',   desc: 'Bu lezzet dünyayı sarsacak',                    price: 4e9,         mult: 25, type: 'click', icon: '🌟' },
  // ─ Tüm Gelir Geliştirmeleri ─
  { id: 'menu1',   name: 'Renkli Menü',       desc: 'Tüm gelir kaynaklarına +%50 zam',               price: 15_000,      mult: 1.5,type: 'all',   icon: '📋' },
  { id: 'menu2',   name: 'Reklam Kampanyası', desc: 'Müşteri sayısı x2 olur',                        price: 750_000,     mult: 2,  type: 'all',   icon: '📺' },
  { id: 'menu3',   name: 'Franchise Sistemi', desc: 'Tüm gelir x3 katlanır',                         price: 80_000_000,  mult: 3,  type: 'all',   icon: '🏛️' },
  { id: 'menu4',   name: 'Marka Değeri',      desc: 'Dünya markası, tüm gelir x4',                   price: 12e9,        mult: 4,  type: 'all',   icon: '👑' },
];

/**
 * Elmas Geliştirmeleri (premium para)
 * Kalıcı: prestij sıfırlamasında korunur.
 */
const GEM_UPGRADES = [
  // Offline gelir süresi
  { id: 'offline4h',  name: '4 Saat Gece Mesaisi', desc: 'Dükkan sen yokken 4 saat daha para kazanır',  icon: '⏰',  cost: 5 },
  { id: 'offline12h', name: '12 Saat Paket Servis', desc: 'Dükkan sen yokken 12 saat para kazanır',     icon: '⌚',  cost: 20, requires: 'offline4h' },
  { id: 'offline48h', name: '7/24 Açık',           desc: 'Dükkan sen yokken 48 saat aralıksız kazanır', icon: '📅',  cost: 60, requires: 'offline12h' },
  // Tıklama gücü
  { id: 'click_gem',  name: 'Altın Spatula',       desc: 'Kalıcı olarak x2 tıklama gücü',                icon: '✨',  cost: 15, type: 'click', mult: 2 },
  { id: 'click_gem2', name: 'Platin Spatula',      desc: 'Kalıcı olarak x3 tıklama gücü (toplam x6)',    icon: '👑',  cost: 45, requires: 'click_gem', type: 'click', mult: 3 },
  // Boost
  { id: 'boost_gem',  name: 'Rush Hour',           desc: 'x2 Yoğunluk süresi 30→45 saniye olur',         icon: '⏳',  cost: 12 },
  { id: 'boost_gem2', name: 'Akşam Mesaisi',       desc: 'x2 Yoğunluk x3 olur (üstüne katlanır)',        icon: '🔥',  cost: 80, requires: 'boost_gem' },
  // Düşen para
  { id: 'coin_gem',   name: 'Cömert Müşteriler',   desc: 'Düşen bahşişler x2 kazandırır',                icon: '💸',  cost: 10 },
  { id: 'coin_gem2',  name: 'VIP Müşteriler',      desc: 'Düşen bahşişler x4 kazandırır (toplam)',       icon: '💰',  cost: 50, requires: 'coin_gem' },
  // Tüm gelir kalıcı
  { id: 'all_gem',    name: 'Lezzet Sırrı',        desc: 'Tüm gelir kaynakları kalıcı x1.5 katlanır',    icon: '🌶️', cost: 30, type: 'all', mult: 1.5 },
  { id: 'all_gem2',   name: 'Dünya Lezzeti',       desc: 'Tüm gelir kaynakları kalıcı x2 katlanır',      icon: '🌎', cost: 100, requires: 'all_gem', type: 'all', mult: 2 },
];

/**
 * Başarımlar — kazandıkça kalıcı +%1 SPS bonus verir
 */
const ACHIEVEMENTS = [
  // Para
  { id: 'sat1k',   name: 'İlk Binlik',       desc: 'Kasadaki ilk 1.000 $',          icon: '💰', check: s => s.total >= 1_000 },
  { id: 'sat100k', name: '100 Bin $',        desc: 'İşler büyüyor!',                icon: '💵', check: s => s.total >= 100_000 },
  { id: 'sat1m',   name: 'Milyoner Patron',  desc: 'İlk Milyon Dolar!',             icon: '💎', check: s => s.total >= 1_000_000 },
  { id: 'sat10m',  name: '10 Milyon $',      desc: 'Sektörün devlerindensin',       icon: '🥈', check: s => s.total >= 10_000_000 },
  { id: 'btc1',    name: '100 Milyon $',     desc: 'Forbes dergisine kapak oldun',  icon: '🤑', check: s => s.total >= 100_000_000 },
  { id: 'btc10',   name: '1 Milyar $',       desc: 'Artık milyardersin',            icon: '🦅', check: s => s.total >= 1e9 },
  { id: 'btc100',  name: '10 Milyar $',      desc: 'Fast Food Kralı',               icon: '🐋', check: s => s.total >= 1e10 },
  { id: 'btc1k',   name: '100 Milyar $',     desc: 'Dünya ekonomisini yönetiyorsun',icon: '🦈', check: s => s.total >= 1e11 },
  { id: 'btc1m',   name: 'Sonsuz Servet',    desc: 'Para sayma makinesi bozuldu',   icon: '👑', check: s => s.total >= 1e14 },

  // Tıklama
  { id: 'clk100',  name: '100 Sipariş',      desc: 'Izgara ısınmaya başladı',       icon: '👊', check: s => s.clicks >= 100 },
  { id: 'clk1k',   name: '1.000 Sipariş',    desc: 'Bilek gücü!',                   icon: '🤜', check: s => s.clicks >= 1000 },
  { id: 'clk10k',  name: '10.000 Sipariş',   desc: 'Spatula ustası',                icon: '🦾', check: s => s.clicks >= 10000 },
  { id: 'clk100k', name: '100 Bin Sipariş',  desc: 'Durdurulamaz şef',              icon: '🤖', check: s => s.clicks >= 100000 },

  // Ekipman
  { id: 'dev5',    name: '5 Ekipman',        desc: 'Mutfak kalabalıklaşıyor',       icon: '🍳', check: s => s.devices >= 5 },
  { id: 'dev10',   name: '10 Ekipman',       desc: 'İyi bir sistem kurdun',         icon: '🏚️', check: s => s.devices >= 10 },
  { id: 'dev25',   name: '25 Ekipman',       desc: 'Şube dolup taşıyor',            icon: '🔌', check: s => s.devices >= 25 },
  { id: 'dev50',   name: '50 Ekipman',       desc: 'Sanayi üretimi burgerler',      icon: '🏭', check: s => s.devices >= 50 },
  { id: 'dev100',  name: '100 Ekipman',      desc: 'Kusursuz bir fabrika',          icon: '🏙️', check: s => s.devices >= 100 },
  { id: 'dev250',  name: '250 Ekipman',      desc: 'Şehir efsanesi',                icon: '🗼', check: s => s.devices >= 250 },
  { id: 'dev500',  name: '500 Ekipman',      desc: 'Her köşe başında sen varsın',   icon: '🏗️', check: s => s.devices >= 500 },
  { id: 'dev1000', name: '1.000 Ekipman',    desc: 'Tedarik zinciri çöktü',         icon: '🌋', check: s => s.devices >= 1000 },
  { id: 'dev2500', name: '2.500 Ekipman',    desc: 'Tüm dünya sadece burger yiyor', icon: '🌐', check: s => s.devices >= 2500 },

  // SPS
  { id: 'sps100',  name: '100 $/sn',         desc: 'Akarken doldur',                icon: '⚡', check: s => s.sps >= 100 },
  { id: 'sps10k',  name: '10 Bin $/sn',      desc: 'Dükkan para basıyor',           icon: '🚀', check: s => s.sps >= 10_000 },
  { id: 'sps1m',   name: '1 Milyon $/sn',    desc: 'Dakikada zenginsin',            icon: '🌊', check: s => s.sps >= 1_000_000 },
  { id: 'sps1b',   name: '1 Milyar $/sn',    desc: 'Merkez bankası gibisin',        icon: '🏆', check: s => s.sps >= 1e9 },
  { id: 'sps1t',   name: '1 Trilyon $/sn',   desc: 'Matematik yetersiz',            icon: '🌠', check: s => s.sps >= 1e12 },

  // Süre
  { id: 'time1m',  name: 'İlk Dakika',       desc: 'Mutfağa hoş geldin',            icon: '⏱️', check: s => s.playtime >= 60 },
  { id: 'hodl',    name: 'Mola Yok!',        desc: '10 dakikadır çalışıyorsun',     icon: '💪', check: s => s.playtime >= 600 },
  { id: 'time30m', name: 'Yarım Saat',       desc: 'Patatesler kızardı',            icon: '☕', check: s => s.playtime >= 1800 },
  { id: 'moon',    name: 'Yoğun Mesai',      desc: '1 saat devrildi',               icon: '🌕', check: s => s.playtime >= 3600 },
  { id: 'time3h',  name: '3 Saat',           desc: 'Ciddi bir yatırımcı',           icon: '🔥', check: s => s.playtime >= 10800 },
  { id: 'time6h',  name: '6 Saat',           desc: 'Telefonun şarjı dayanıyor mu?', icon: '🌡️', check: s => s.playtime >= 21600 },
  { id: 'time24h', name: 'Tam Bir Gün',      desc: '24 saattir oyun açık!',         icon: '🛌', check: s => s.playtime >= 86400 },
  { id: 'time7d',  name: 'Bir Hafta',        desc: '7 gün... Gerçek bir patron.',   icon: '📅', check: s => s.playtime >= 604800 },

  // Mükemmellik
  { id: 'allup',   name: 'Mükemmel Dükkan',  desc: 'Tüm geliştirmeleri satın aldın',icon: '⭐', check: s => s.upgCount >= UPGRADES.length },

  // Prestij
  { id: 'pres1',   name: 'İlk Şube',         desc: 'Prestij yaptın, yeni şube açtın',icon: '🚚', check: s => s.prestigeRuns >= 1 },
  { id: 'pres5',   name: '5. Şube',          desc: 'Zincir restoran oldun',         icon: '🔄', check: s => s.prestigeRuns >= 5 },
  { id: 'pres25',  name: '25. Şube',         desc: 'Acımasız büyüme',               icon: '🌀', check: s => s.prestigeRuns >= 25 },
  { id: 'prespts', name: '100 Prestij Puanı',desc: 'Kazancın katlanıyor',           icon: '📈', check: s => s.prestigePoints >= 100 },
  { id: 'prespts1k',name: '1.000 Prestij Puanı',desc: 'Prestijin efendisi',         icon: '📊', check: s => s.prestigePoints >= 1000 },

  // Personel
  { id: 'mgr1',    name: 'İlk Çalışan',      desc: 'Birini işe aldın',              icon: '👦', check: s => (s.managers || {})['intern'] >= 1 },
  { id: 'mgr5',    name: 'Büyük Ekip',       desc: '5 yöneticiye ulaştın',          icon: '👥', check: s => Object.values(s.managers || {}).reduce((a, b) => a + b, 0) >= 5 },
  { id: 'mgrall',  name: 'Tam Kadro',        desc: 'Her seviyeden personelin var',  icon: '🎖️', check: s => MANAGERS.every(m => (s.managers || {})[m.id] >= 1) },

  // Elmas
  { id: 'gem10',   name: 'Elmas Avcısı',     desc: '10 elmas biriktir',             icon: '💎', check: s => (s.gemsEverEarned || 0) >= 10 },
  { id: 'gem50',   name: 'Elmas Koleksiyoneri', desc: '50 elmas kazan',             icon: '🔮', check: s => (s.gemsEverEarned || 0) >= 50 },
  { id: 'gemshop1',name: 'İlk Lüks',         desc: 'İlk elmas geliştirmen',         icon: '✨', check: s => Object.keys(s.gemUpgrades || {}).length >= 1 },

  // Gizli olaylar
  { id: 'goldstar',name: 'Şanslı Patron',    desc: 'Altın burgeri yakaladın',       icon: '⭐', check: s => (s.goldenCaught || 0) >= 1 },
  { id: 'streak3', name: 'Sadık Müşteri',    desc: '3 gün üst üste giriş',          icon: '🎁', check: s => (s.loginStreak || 0) >= 3 },
  { id: 'streak7', name: 'Vazgeçemiyor',     desc: '7 gün üst üste giriş',          icon: '🏅', check: s => (s.loginStreak || 0) >= 7 },
];

/**
 * Personel — pasif olarak otomatik tıklar
 * her tıklama tıklama gücü kadar para getirir
 */
const MANAGERS = [
  { id: 'intern',  name: 'Komi',             emoji: '👦',   basePrice: 5_000,         clicksPerSec: 1,    desc: 'Ortalığı toplar, ufak işleri halleder' },
  { id: 'trader',  name: 'Kasiyer',          emoji: '👩‍💻',  basePrice: 18_000,        clicksPerSec: 3,    desc: 'Siparişleri hızlıca sisteme girer' },
  { id: 'quant',   name: 'Usta Şef',         emoji: '👨‍🍳',  basePrice: 150_000,       clicksPerSec: 15,   desc: 'Aynı anda üç tavada et pişirir' },
  { id: 'aibot',   name: 'Restoran Müdürü',  emoji: '🕴️',   basePrice: 1_500_000,     clicksPerSec: 80,   desc: 'Her şeyi otomatiğe bağlar, denetler' },
  { id: 'quantum', name: 'Bölge CEO\'su',    emoji: '🏢',    basePrice: 20_000_000,    clicksPerSec: 500,  desc: 'Dükkanı kurumsal bir deve dönüştürür' },
  { id: 'global',  name: 'Global Direktör',  emoji: '✈️',    basePrice: 350_000_000,   clicksPerSec: 3000, desc: 'Dünya çapında operasyon yönetiyor' },
];

/**
 * Haber Şeridi — alt taraftaki kayan haberler
 */
const NEWS_TICKER = [
  '🍔 Müşteri: "Vegan burger var mı?" Biz: "Patates kızartması var."',
  '🗣️ Sağlık müfettişi dükkana geldi, burgerden bir ısırık alıp ağlayarak sarıldı.',
  '📈 Rakip restoranın patatesleri lastik gibiymiş, müşteriler bize akın ediyor!',
  '📱 TikTok fenomenleri gizli sosumuzu ifşa etti, kapıda 3 kilometre kuyruk var.',
  '💸 Bir müşteri siparişine yanlışlıkla 10.000$ bahşiş bıraktı. Geri vermedik.',
  '🚚 Domates tedarikçimiz yolda kaza yapmış, bugün burgerler domatessiz.',
  '⭐ Gurme dergileri "Şehrin En Salaş Ama En Lezzetli Mekanı" olarak bizi seçti.',
  '🔥 Mutfaktaki çırak yanlışlıkla acı sosu fazla kaçırmış, müşteri itfaiye çağırdı.',
  '🤝 Belediye başkanı gizlice gelip iki porsiyon yemiş. Ruhsat sorunumuz çözüldü!',
  '🐭 Depoda bir fare görüldü ama merak etmeyin, o da sadece peynir çalıyor.',
  '🍟 "Patatesim soğuk" diyen müşteriye fritöz hediye ettik, artık kendi yapıyor.',
  '💼 Patron yine ortalarda yok, kesin arka odada paraları sayıyor.',
  '🥤 İçecek makinesi bozuldu, kolaya su katıp satıyoruz fark etmediler bile.',
  '🚗 Arabaya servis sırasında bir Formula 1 aracı sipariş verdi. 2 saniyede teslim ettik.',
  '🥩 Menüye "Altın Kaplama Burger" ekledik, sadece zenginler alıyor ama maliyeti 5 lira.',
  '🧑‍🍳 Şefimiz işi bıraktı. Yerine giren kurye daha iyi burger yapıyor.',
  '🚨 Dükkan o kadar kalabalık ki, içerideki oksijen azaldığı için alarm çaldı.',
  '🏆 "Yılın En İyi İşletmecisi" ödülünü aldık (Rüşvet verdiğimiz kimseye söylenmedi).',
  '🤑 Kasiyerimiz para üstü verirken matematik kuralı ihlali yaptı, şirket %20 kâra geçti.',
  '🌍 Haberler: Ünlü Hollywood yıldızı gizlice dükkanımızda hamburger yedi!',
  '🎬 Netflix bir belgesel çekti: "Bir Burgerin Ardından". Yorumlar karışık.',
  '🍔 Yeni menümüz "Acı Bomba" 3 kişiyi hastaneye gönderdi. Reklam çığ gibi büyüdü.',
  '🚁 Helikopterle paket servis denemesi: Burgerler salata oldu ama tanıtım başarılı.',
  '🦄 Tek boynuzlu at burgerimiz hayvanseverleri kızdırdı, satışlar üçe katlandı.',
  '🤖 Robot garson siparişleri yanlış aldı, müşteriler "yeni lezzet" sandı.',
];

/**
 * Günlük Ödüller — 7 gün döngüsü
 * type: 'cash' (sps × seconds), 'gems' (sabit), 'boost' (saniye)
 */
const DAILY_REWARDS = [
  { day: 1, type: 'cash',  amount: 300,    desc: '5 dk kazanç',      icon: '💵' },
  { day: 2, type: 'gems',  amount: 2,      desc: '2 Elmas',          icon: '💎' },
  { day: 3, type: 'cash',  amount: 900,    desc: '15 dk kazanç',     icon: '💰' },
  { day: 4, type: 'boost', amount: 60,     desc: '60 sn x2 Boost',   icon: '⚡' },
  { day: 5, type: 'gems',  amount: 5,      desc: '5 Elmas',          icon: '🔷' },
  { day: 6, type: 'cash',  amount: 1800,   desc: '30 dk kazanç',     icon: '🤑' },
  { day: 7, type: 'gems',  amount: 15,     desc: '15 Elmas! BÜYÜK',  icon: '🏆' },
];
