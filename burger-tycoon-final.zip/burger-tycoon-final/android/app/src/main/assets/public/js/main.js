/* ═══════════════════════════════════════════
   main.js — Giriş noktası, oyun döngüsü, tablar
   Burger Tycoon
   ═══════════════════════════════════════════ */
'use strict';

// ── Reklam butonu görünürlüğü ────────────────────────

function updateAdsVisibility() {
  const adsBtn = document.getElementById('side-ads-btn');
  if (!adsBtn) return;

  const activePanel = document.querySelector('.tab-panel.active');
  const isMinePage = activePanel && activePanel.id === 'mine-panel';

  const modalOpen =
    document.getElementById('prestige-modal')?.classList.contains('show') ||
    document.getElementById('gem-modal')?.classList.contains('show') ||
    document.getElementById('offline-modal')?.classList.contains('show') ||
    document.getElementById('reset-modal')?.classList.contains('show') ||
    document.getElementById('currency-modal')?.classList.contains('show') ||
    document.getElementById('daily-modal')?.classList.contains('show') ||
    document.getElementById('tutorial-modal')?.classList.contains('show') ||
    document.getElementById('game-confirm-modal')?.classList.contains('show');

  adsBtn.style.display = (G.noAds || !isMinePage || modalOpen) ? 'none' : 'flex';
}

// ── Genel onay modalı ────────────────────────────────

function gameConfirm(icon, title, desc, okText, cancelText, onOk) {
  let modal = document.getElementById('game-confirm-modal');

  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'game-confirm-modal';
    modal.innerHTML = `
      <div id="game-confirm-box">
        <div id="game-confirm-icon"></div>
        <div id="game-confirm-title"></div>
        <div id="game-confirm-desc"></div>
        <div id="game-confirm-buttons">
          <button id="game-confirm-cancel"></button>
          <button id="game-confirm-ok"></button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  }

  document.getElementById('game-confirm-icon').textContent = icon;
  document.getElementById('game-confirm-title').textContent = title;
  document.getElementById('game-confirm-desc').textContent = desc;
  document.getElementById('game-confirm-ok').textContent = okText || 'Tamam';
  document.getElementById('game-confirm-cancel').textContent = cancelText || 'Vazgeç';

  modal.classList.add('show');
  updateAdsVisibility();

  document.getElementById('game-confirm-cancel').onclick = () => {
    modal.classList.remove('show');
    updateAdsVisibility();
  };

  document.getElementById('game-confirm-ok').onclick = () => {
    modal.classList.remove('show');
    updateAdsVisibility();
    if (typeof onOk === 'function') onOk();
  };
}

// ── Haber şeridi ─────────────────────────────────────

(function initTicker() {
  const wrap = document.getElementById('ticker-wrap');
  const icon = document.getElementById('ticker-icon');
  const el = document.getElementById('ticker-text');

  if (!wrap || !el || typeof NEWS_TICKER === 'undefined' || !NEWS_TICKER.length) return;

  let idx = Math.floor(Math.random() * NEWS_TICKER.length);
  let nextTimer;

  function showNext() {
    el.classList.remove('ticker-visible', 'ticker-scroll');
    el.style.removeProperty('--ticker-offset');
    el.style.removeProperty('--ticker-dur');
    el.style.removeProperty('--ticker-delay');

    setTimeout(() => {
      el.textContent = NEWS_TICKER[idx % NEWS_TICKER.length];
      idx++;
      el.classList.add('ticker-visible');

      requestAnimationFrame(() => {
        const available = wrap.clientWidth - (icon ? icon.offsetWidth + 18 : 22);
        const overflow = el.offsetWidth - available;

        clearTimeout(nextTimer);
        if (overflow > 8) {
          const scrollPx = overflow + 32;
          const dur = scrollPx / 75;
          const delay = 1.0;

          el.style.setProperty('--ticker-offset', `-${scrollPx}px`);
          el.style.setProperty('--ticker-dur', `${dur.toFixed(1)}s`);
          el.style.setProperty('--ticker-delay', `${delay}s`);
          el.classList.add('ticker-scroll');

          nextTimer = setTimeout(showNext, (delay + dur + 1.5) * 1000);
        } else {
          nextTimer = setTimeout(showNext, 9000);
        }
      });
    }, 350);
  }

  showNext();
})();

// ── Tema (light/dark) ────────────────────────────────

(function initTheme() {
  const app = document.getElementById('app');
  const btn = document.getElementById('theme-btn');
  if (!app || !btn) return;

  const saved = localStorage.getItem('btc_theme') || 'dark';

  if (saved === 'light') {
    app.dataset.theme = 'light';
    btn.textContent = '🌙';
  }

  btn.addEventListener('click', () => {
    const isLight = app.dataset.theme === 'light';
    app.dataset.theme = isLight ? 'dark' : 'light';
    btn.textContent = isLight ? '☀️' : '🌙';
    localStorage.setItem('btc_theme', app.dataset.theme);
    sndClick();
  });
})();

// ── Para birimleri modalı ────────────────────────────

(function initCurrencyModal() {
  const modal = document.getElementById('currency-modal');
  const note = document.getElementById('currency-sat-eq');
  const balanceDisplay = document.getElementById('balance-display');
  const balanceHint = document.getElementById('balance-hint');
  const closeBtn = document.getElementById('currency-close');

  if (!modal || !note) return;

  function openCurrencyModal() {
    note.textContent = 'Şu anki kasan: ' + fmtBalance(G.sat) +
      ' (Tam olarak ' + fmt(G.sat) + ' $)';
    modal.classList.add('show');
    updateAdsVisibility();
  }

  if (balanceDisplay) balanceDisplay.addEventListener('click', openCurrencyModal);
  if (balanceHint) balanceHint.addEventListener('click', openCurrencyModal);
  if (closeBtn) closeBtn.addEventListener('click', () => {
    modal.classList.remove('show');
    updateAdsVisibility();
  });

  modal.addEventListener('click', e => {
    if (e.target === modal) {
      modal.classList.remove('show');
      updateAdsVisibility();
    }
  });
})();

// ── Reset ────────────────────────────────────────────

window.resetGame = function () {
  const modal = document.getElementById('reset-modal');
  if (modal) {
    modal.classList.add('show');
    updateAdsVisibility();
  }
};

window.addSat = function (amount) {
  amount = Math.floor(Number(amount) || 0);
  G.sat += amount;
  G.total += amount;
  save();
  renderHeader();
  renderStats();
};

window.addGems = function (amount) {
  amount = Math.floor(Number(amount) || 0);
  G.gems = (G.gems || 0) + amount;
  G.gemsEverEarned = (G.gemsEverEarned || 0) + Math.max(0, amount);
  save();
  renderHeader();
  renderStats();
  checkAchievements();
};

// ── VIP / Reklam kaldırma ────────────────────────────

window.buyRemoveAds = function () {
  if (G.noAds) {
    showNotice('👑', 'VIP Aktif', 'Zaten reklamsız kullanıyorsun.');
    return;
  }

  gameConfirm(
    '👑',
    'Reklamları Kaldır',
    'VIP paketi aktif olunca:\n• Reklamlar kalkar\n• Kum saati boost reklamsız çalışır\n• Çift offline gelir\n\nFiyat: ₺25.99',
    'Satın Al',
    'Vazgeç',
    function () {
      G.noAds = true;
      save();
      updateAdsVisibility();
      sndPrestige();
      showNotice('✅', 'VIP Aktif!', 'Artık kum saati boost reklamsız çalışacak.');
      if (typeof renderHeader === 'function') renderHeader();
    }
  );
};

function showRewardAdForBoost(onReward) {
  if (G.noAds) { onReward(); return; }
  gameConfirm(
    '📺',
    'Reklamlı Boost',
    'Reklam izleyerek 2x kazanç boost almak ister misin?',
    'Reklam İzle',
    'Vazgeç',
    function () { onReward(); }
  );
}

// ── Reset modalı ─────────────────────────────────────

(function initResetButtons() {
  const cancel = document.getElementById('reset-cancel');
  const confirmBtn = document.getElementById('reset-confirm');

  if (cancel) cancel.addEventListener('click', () => {
    document.getElementById('reset-modal').classList.remove('show');
    updateAdsVisibility();
  });

  if (confirmBtn) confirmBtn.addEventListener('click', () => {
    window.removeEventListener('beforeunload', save);
    localStorage.removeItem(SAVE_KEY);
    localStorage.removeItem('burger_tycoon_v1');
    location.reload();
  });
})();

// ── Prestij modalı ───────────────────────────────────

(function initPrestigeModal() {
  const openBtn = document.getElementById('prestige-open-btn');
  const cancelBtn = document.getElementById('prestige-cancel');
  const confirmBtn = document.getElementById('prestige-confirm');

  if (openBtn) {
    openBtn.addEventListener('click', () => {
      const gain = calcPrestigeGain();
      const curPoints = G.prestigePoints;
      const newTotal = curPoints + gain;
      const curBonus = (curPoints * 2).toFixed(0);
      const newBonus = (newTotal * 2).toFixed(0);

      document.getElementById('pconf-gain').textContent = gain > 0 ? '+' + gain + ' Puan' : '—';
      document.getElementById('pconf-total').textContent = gain > 0
        ? curPoints + ' → ' + newTotal + ' Puan'
        : curPoints + ' Puan';
      document.getElementById('pconf-bonus').textContent = gain > 0
        ? '+' + curBonus + '% → +' + newBonus + '%'
        : '+' + curBonus + '%';

      confirmBtn.disabled = gain <= 0;
      document.getElementById('prestige-modal').classList.add('show');
      updateAdsVisibility();
    });
  }

  if (cancelBtn) cancelBtn.addEventListener('click', () => {
    document.getElementById('prestige-modal').classList.remove('show');
    updateAdsVisibility();
  });

  if (confirmBtn) confirmBtn.addEventListener('click', () => {
    document.getElementById('prestige-modal').classList.remove('show');

    if (doPrestige()) {
      sndPrestige();
      vibe([60, 40, 60]);
    }
    recalcMults();
    G.sps = calcSps();

    renderHeader();
    renderStats();
    renderShop();
    renderUpgrades();
    renderAchievements();
    renderGemShop();
    checkAchievements();
    save();
    updateAdsVisibility();
  });

  // Modal arkaplanına tıklayınca kapansın
  const modal = document.getElementById('prestige-modal');
  if (modal) {
    modal.addEventListener('click', e => {
      if (e.target === modal) {
        modal.classList.remove('show');
        updateAdsVisibility();
      }
    });
  }
})();

// ── Offline modalı ───────────────────────────────────

function showOfflineModal(sec, earned) {
  const MAX = calcOfflineMax();
  const pct = Math.min(sec / MAX * 100, 100).toFixed(1);

  document.getElementById('offline-earned').textContent = '+' + fmtBalance(earned);
  document.getElementById('offline-bar-fill').style.width = pct + '%';
  document.getElementById('offline-time-val').textContent = fmtTime(sec) + ' / ' + fmtTime(MAX);

  // Reklam izle x2 butonu (varsa) — burada sadece basit bir close
  document.getElementById('offline-modal').classList.add('show');
  updateAdsVisibility();
}

(function initOfflineModal() {
  const close = document.getElementById('offline-close');
  if (close) close.addEventListener('click', () => {
    document.getElementById('offline-modal').classList.remove('show');
    save();
    updateAdsVisibility();
  });
})();

// ── Elmas modalı ─────────────────────────────────────

(function initGemModal() {
  const gemBtn = document.getElementById('gem-btn');
  const close = document.getElementById('gem-modal-close');
  const modal = document.getElementById('gem-modal');

  if (gemBtn) gemBtn.addEventListener('click', () => {
    renderGemShop();
    modal.classList.add('show');
    updateAdsVisibility();
  });

  if (close) close.addEventListener('click', () => {
    modal.classList.remove('show');
    updateAdsVisibility();
  });

  if (modal) modal.addEventListener('click', e => {
    if (e.target === modal) {
      modal.classList.remove('show');
      updateAdsVisibility();
    }
  });
})();

// ── Satın alma modu ──────────────────────────────────

(function initBuyMode() {
  const MODES = [1, 10, 0];
  const LABELS = ['×1', '×10', 'Maks'];
  const fab = document.getElementById('buy-mode-fab');
  if (!fab) return;

  // İlk yükleme: doğru etiketi göster
  const startIdx = MODES.indexOf(G.buyMode);
  if (startIdx >= 0) {
    fab.textContent = LABELS[startIdx];
    fab.dataset.mode = G.buyMode;
  }

  fab.addEventListener('click', () => {
    const idx = MODES.indexOf(G.buyMode);
    const next = ((idx < 0 ? 0 : idx) + 1) % MODES.length;
    G.buyMode = MODES[next];
    fab.textContent = LABELS[next];
    fab.dataset.mode = G.buyMode;
    sndClick();
    renderShop();
  });
})();

// ── Tab değişimi ─────────────────────────────────────

(function initTabs() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;

      document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      const panel = document.getElementById(tab + '-panel');
      if (panel) panel.classList.add('active');

      sndClick();

      if (tab === 'shop') renderShop();
      if (tab === 'upgrades') renderUpgrades();
      if (tab === 'ach') renderAchievements();
      if (tab === 'stats') renderStatPanel();

      updateAdsVisibility();
    });
  });
})();

// ── Düşen paralar ────────────────────────────────────

(function initDropCoins() {
  const app = document.getElementById('app');
  let activeCoins = 0;
  const MAX_COINS = 3;
  if (!app) return;

  function coinReward() {
    const base = Math.max(Math.ceil(G.sps * 15), calcClickPow() * 50);
    let mult = 1;
    if (G.gemUpgrades['coin_gem'])  mult *= 2;
    if (G.gemUpgrades['coin_gem2']) mult *= 2; // toplam x4
    return base * mult;
  }

  function spawnCoin() {
    if (activeCoins >= MAX_COINS) { scheduleNext(); return; }

    const reward = coinReward();
    const fallDur = (4.5 + Math.random() * 3).toFixed(2);
    const leftPct = 8 + Math.random() * 72;

    const el = document.createElement('div');
    el.className = 'drop-coin';
    el.style.left = leftPct + '%';
    el.style.setProperty('--fall-dur', fallDur + 's');

    el.innerHTML =
      '<div class="drop-coin-icon">💵</div>' +
      '<div class="drop-coin-val">+' + fmt(reward) + ' $</div>';

    activeCoins++;

    el.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      G.sat += reward;
      G.total += reward;
      sndCoin();
      vibe(15);

      renderHeader();
      renderStats();
      checkAchievements();
      save();

      const burst = document.createElement('div');
      burst.className = 'drop-collect-burst';
      const r = app.getBoundingClientRect();
      burst.style.left = (e.clientX - r.left) + 'px';
      burst.style.top  = (e.clientY - r.top) + 'px';
      app.appendChild(burst);
      setTimeout(() => burst.remove(), 480);

      spawnFloat(e.clientX, e.clientY, '+' + fmt(reward) + ' $');

      el.remove();
      activeCoins--;
    });

    el.addEventListener('animationend', () => {
      if (el.parentNode) {
        el.remove();
        activeCoins--;
      }
    });

    app.appendChild(el);
    scheduleNext();
  }

  function scheduleNext() {
    setTimeout(spawnCoin, (15 + Math.random() * 25) * 1000);
  }

  setTimeout(spawnCoin, (20 + Math.random() * 15) * 1000);
})();

// ── Düşen boost ──────────────────────────────────────

(function initDropBoost() {
  const app = document.getElementById('app');
  let pending = false;
  if (!app) return;

  function startBoost(e, el, boostSec) {
    activateBoost();
    sndBoost();
    vibe([40, 30, 60]);
    renderBoost();
    const mult = G.boostMult || 2;
    showNotice('⏳', 'Yoğunluk Başladı!', `Siparişler yağıyor! ${boostSec} saniye boyunca x${mult} kazanç!`);

    const burst = document.createElement('div');
    burst.className = 'drop-collect-burst';
    const r = app.getBoundingClientRect();
    burst.style.left = (e.clientX - r.left) + 'px';
    burst.style.top  = (e.clientY - r.top) + 'px';
    app.appendChild(burst);
    setTimeout(() => burst.remove(), 480);

    el.remove();
    pending = false;
    scheduleNext();
    save();
  }

  function spawnBoost() {
    if (pending || (G.boostActive && Date.now() < G.boostEndsAt)) {
      scheduleNext();
      return;
    }

    pending = true;

    const fallDur = (5 + Math.random() * 3).toFixed(2);
    const leftPct = 8 + Math.random() * 72;
    const boostSec = calcBoostDuration();

    const el = document.createElement('div');
    el.className = 'drop-boost';
    el.style.left = leftPct + '%';
    el.style.setProperty('--fall-dur', fallDur + 's');

    el.innerHTML =
      `<div class="drop-boost-icon">⏳</div>` +
      `<div class="drop-boost-val">${G.noAds ? 'VIP ' : 'Reklamlı '}x2 (${boostSec}sn)</div>`;

    el.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      showRewardAdForBoost(() => startBoost(e, el, boostSec));
    });

    el.addEventListener('animationend', () => {
      if (el.parentNode) {
        el.remove();
        pending = false;
        scheduleNext();
      }
    });

    app.appendChild(el);
  }

  function scheduleNext() {
    setTimeout(spawnBoost, (60 + Math.random() * 60) * 1000);
  }

  setTimeout(spawnBoost, (30 + Math.random() * 30) * 1000);
})();

// ── Düşen elmaslar ───────────────────────────────────

(function initDropGems() {
  const app = document.getElementById('app');
  let pending = false;
  if (!app) return;

  function spawnGem() {
    if (pending) { scheduleNext(); return; }
    pending = true;

    const fallDur = (6 + Math.random() * 4).toFixed(2);
    const leftPct = 10 + Math.random() * 68;

    const el = document.createElement('div');
    el.className = 'drop-gem';
    el.style.left = leftPct + '%';
    el.style.setProperty('--fall-dur', fallDur + 's');
    el.innerHTML = '<div class="drop-gem-icon">💎</div><div class="drop-gem-val">+1 💎</div>';

    el.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      G.gems = (G.gems || 0) + 1;
      G.gemsEverEarned = (G.gemsEverEarned || 0) + 1;
      sndGem();
      vibe([20, 40, 20]);
      renderGemCount();
      save();
      showNotice('💎', 'Gizli Müşteri!', `Elmas bahşiş bıraktı! Toplam: ${G.gems} 💎`);

      const burst = document.createElement('div');
      burst.className = 'drop-collect-burst gem-burst';
      const r = app.getBoundingClientRect();
      burst.style.left = (e.clientX - r.left) + 'px';
      burst.style.top  = (e.clientY - r.top) + 'px';
      app.appendChild(burst);
      setTimeout(() => burst.remove(), 480);

      spawnFloat(e.clientX, e.clientY, '+1 💎');

      el.remove();
      pending = false;
      checkAchievements();
      scheduleNext();
    });

    el.addEventListener('animationend', () => {
      if (el.parentNode) {
        el.remove();
        pending = false;
        scheduleNext();
      }
    });

    app.appendChild(el);
  }

  function scheduleNext() {
    const delay = (5 + Math.random() * 10) * 60 * 1000;
    setTimeout(spawnGem, delay);
  }

  setTimeout(spawnGem, (120 + Math.random() * 120) * 1000);
})();

// ── Altın Burger Event (Şanslı yakalanırsa büyük ödül) ─

(function initGoldenBurger() {
  const app = document.getElementById('app');
  let pending = false;
  if (!app) return;

  function spawn() {
    // sadece $1 milyon kazanmıştır oyuncu — yoksa düşme
    if (pending || G.total < 1_000_000) {
      setTimeout(spawn, 60_000);
      return;
    }
    pending = true;

    const fallDur = (3.5 + Math.random() * 2).toFixed(2);
    const leftPct = 10 + Math.random() * 70;
    // ödül: oyuncunun toplam kazancının ~%2-5'i veya sps × 5dk
    const reward = Math.max(Math.floor(G.total * 0.03), Math.floor(G.sps * 300));

    const el = document.createElement('div');
    el.className = 'drop-coin drop-golden';
    el.style.left = leftPct + '%';
    el.style.setProperty('--fall-dur', fallDur + 's');
    el.innerHTML =
      '<div class="drop-coin-icon" style="font-size:1.8rem; background: radial-gradient(circle at 38% 30%, #fff8b0 0%, #ffd700 50%, #b8860b 100%); box-shadow: 0 0 0 3px gold, 0 0 28px gold, 0 0 60px rgba(255,215,0,0.5);">🌟</div>' +
      '<div class="drop-coin-val" style="background: rgba(180,120,0,0.85); color:#fff8b0;">ALTIN! +' + fmt(reward) + ' $</div>';

    el.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      G.sat += reward;
      G.total += reward;
      G.goldenCaught = (G.goldenCaught || 0) + 1;
      sndPrestige();
      vibe([60, 40, 80, 40, 60]);

      const burst = document.createElement('div');
      burst.className = 'drop-collect-burst';
      burst.style.borderColor = 'gold';
      const r = app.getBoundingClientRect();
      burst.style.left = (e.clientX - r.left) + 'px';
      burst.style.top  = (e.clientY - r.top) + 'px';
      app.appendChild(burst);
      setTimeout(() => burst.remove(), 480);

      spawnFloat(e.clientX, e.clientY, '🌟 +' + fmt(reward) + ' $');
      showNotice('🌟', 'Altın Burger!', `+${fmtBalance(reward)} kazandın!`);

      renderHeader();
      renderStats();
      checkAchievements();
      save();

      el.remove();
      pending = false;
      scheduleNext();
    });

    el.addEventListener('animationend', () => {
      if (el.parentNode) {
        el.remove();
        pending = false;
        scheduleNext();
      }
    });

    app.appendChild(el);
  }

  function scheduleNext() {
    // 4-8 dakika arası bir altın burger
    const delay = (4 + Math.random() * 4) * 60 * 1000;
    setTimeout(spawn, delay);
  }

  // İlk altın burger 3-6 dakika sonra
  setTimeout(spawn, (3 + Math.random() * 3) * 60 * 1000);
})();

// ── Daily Reward (Günlük Ödül) ───────────────────────

function checkDailyReward() {
  const today = todayStr();
  if (G.lastClaimDate === today) return; // bugün alındı

  // Hangi günü açacağı belirle
  let day = (G.loginStreak || 0) + 1;
  // Eğer dün giriş yapılmadıysa (atlandıysa) seriyi sıfırla
  const yesterday = dayAfter(G.lastClaimDate);
  if (G.lastClaimDate && yesterday !== today) {
    day = 1; // yeni seri
  }
  // 7 günden büyükse 1'e dön
  if (day > 7) day = 1;

  showDailyModal(day);
}

function showDailyModal(day) {
  const reward = DAILY_REWARDS[day - 1];
  if (!reward) return;

  let modal = document.getElementById('daily-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'daily-modal';
    modal.innerHTML = `
      <div id="daily-box">
        <div id="daily-icon">🎁</div>
        <div id="daily-title">Günlük Hediye!</div>
        <div id="daily-streak"></div>
        <div id="daily-row"></div>
        <div id="daily-reward-desc"></div>
        <button id="daily-claim">🎁 Hediyeyi Al</button>
      </div>
    `;
    document.body.appendChild(modal);
  }

  // Streak göster (7 daire)
  const streakHtml = DAILY_REWARDS.map((r, i) => {
    const dayNum = i + 1;
    const claimed = dayNum < day;
    const today = dayNum === day;
    return `<div class="daily-day ${claimed ? 'claimed' : ''} ${today ? 'today' : ''}">
      <div class="daily-day-num">G${dayNum}</div>
      <div class="daily-day-icon">${r.icon}</div>
    </div>`;
  }).join('');
  document.getElementById('daily-row').innerHTML = streakHtml;

  document.getElementById('daily-streak').textContent = `${day}. Gün serisinde`;
  document.getElementById('daily-reward-desc').textContent = `Bugünün ödülü: ${reward.desc}`;

  modal.classList.add('show');
  updateAdsVisibility();

  document.getElementById('daily-claim').onclick = () => {
    claimDaily(day, reward);
    modal.classList.remove('show');
    updateAdsVisibility();
  };
}

function claimDaily(day, reward) {
  if (reward.type === 'cash') {
    // amount = saniye sayısı × sps (oyuncu seviyesine göre)
    const earned = Math.max(1000, Math.floor(G.sps * reward.amount));
    G.sat += earned;
    G.total += earned;
    sndCoin();
    showNotice(reward.icon, `+${fmtBalance(earned)}`, 'Günlük hediye alındı!');
  } else if (reward.type === 'gems') {
    G.gems = (G.gems || 0) + reward.amount;
    G.gemsEverEarned = (G.gemsEverEarned || 0) + reward.amount;
    sndGem();
    showNotice(reward.icon, `+${reward.amount} 💎`, 'Günlük elmas hediye!');
  } else if (reward.type === 'boost') {
    // boost gem yoksa 30s, varsa 45s — burada özel olarak amount kadar veriyoruz
    G.boostActive = true;
    G.boostEndsAt = Date.now() + reward.amount * 1000;
    G.boostMult = G.gemUpgrades['boost_gem2'] ? 3 : 2;
    sndBoost();
    renderBoost();
    showNotice(reward.icon, `+${reward.amount}sn Boost`, 'Günlük yoğunluk!');
  }

  G.lastClaimDate = todayStr();
  G.loginStreak = day;
  vibe([30, 50, 80]);

  renderHeader();
  renderStats();
  checkAchievements();
  save();
}

// ── Tutorial (ilk açılış) ────────────────────────────

function showTutorial() {
  let modal = document.getElementById('tutorial-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'tutorial-modal';
    modal.innerHTML = `
      <div id="tutorial-box">
        <div id="tutorial-icon">🍔</div>
        <div id="tutorial-title">Burger Tycoon'a Hoş Geldin!</div>
        <div id="tutorial-body">
          <div class="tut-step"><b>1.</b> 🍔 Burgere tıklayarak para kazan</div>
          <div class="tut-step"><b>2.</b> 🛒 Dükkan sekmesinden ekipman al — otomatik kazanç</div>
          <div class="tut-step"><b>3.</b> 📈 Geliştir sekmesinden tıklama gücünü artır</div>
          <div class="tut-step"><b>4.</b> 💎 Düşen elmasları topla — özel iyileştirmeler</div>
          <div class="tut-step"><b>5.</b> 🚚 Yeterince büyüdüğünde "Yeni Şube Aç" ile prestij kazan</div>
          <div class="tut-step"><b>6.</b> 🏆 Başarımları topla — her biri +%1 kalıcı bonus + 1💎</div>
        </div>
        <button id="tutorial-close">Hadi Başlayalım!</button>
      </div>
    `;
    document.body.appendChild(modal);
  }
  modal.classList.add('show');
  updateAdsVisibility();

  document.getElementById('tutorial-close').onclick = () => {
    modal.classList.remove('show');
    G.tutorialDone = true;
    save();
    updateAdsVisibility();
  };
}

// ── Ana oyun döngüsü ─────────────────────────────────

let _lastTick = Date.now();
let _ticksSinceShopRender = 0;
let _autoClickVisTimer = 0;
let _spsAccum = 0;

setInterval(() => {
  const now = Date.now();
  const dt = Math.min((now - _lastTick) / 1000, 1);
  _lastTick = now;

  G.sps = calcSps();
  if (G.sps > G.spsRecord) G.spsRecord = G.sps;

  _spsAccum += G.sps * dt;
  const earn = Math.floor(_spsAccum);
  _spsAccum -= earn;

  G.sat += earn;
  G.total += earn;
  G.playtime += dt;

  renderHeader();
  renderStats();
  renderBoost();
  updateShopBadge();
  updateUpgBadge();
  updateFrenzy(dt);
  updateAdsVisibility();

  // Otomatik tıklama (personeller)
  const autoClickSps = calcAutoClick();
  if (autoClickSps > 0) {
    _autoClickVisTimer += dt;
    if (_autoClickVisTimer >= 1) {
      _autoClickVisTimer -= 1;
      const earned = autoClickSps;
      G.sat += earned;
      G.total += earned;
      // görsel feedback
      const coinWrap = document.getElementById('coin-wrap');
      const r = coinWrap ? coinWrap.getBoundingClientRect() : null;
      if (r && r.width > 0 && r.height > 0) {
        spawnAutoFloat(r.left + r.width / 2, r.top + r.height / 2, '+' + fmt(earned) + ' $');
      }
    }
  } else {
    _autoClickVisTimer = 0;
  }

  // Boost süresi bitti mi kontrol et
  if (G.boostActive && Date.now() >= G.boostEndsAt) {
    G.boostActive = false;
    save();
  }

  _ticksSinceShopRender++;
  if (_ticksSinceShopRender >= 5) {
    _ticksSinceShopRender = 0;
    if (document.getElementById('shop-panel')?.classList.contains('active'))     renderShop();
    if (document.getElementById('upgrades-panel')?.classList.contains('active')) renderUpgrades();
    if (document.getElementById('stats-panel')?.classList.contains('active'))    renderStatPanel();
  }

  checkAchievements();
}, 200);

// Düzenli kayıt
setInterval(save, 15000);

// ── Init ─────────────────────────────────────────────

(function init() {
  const offlineSec = load();
  recalcMults();
  G.sps = calcSps();

  if (offlineSec >= 15 && G.sps > 0) {
    // VIP olsa offline gelir x2
    let earned = Math.floor(G.sps * offlineSec);
    if (G.noAds) earned = Math.floor(earned * 2);
    G.sat += earned;
    G.total += earned;
    setTimeout(() => showOfflineModal(offlineSec, earned), 600);
  }

  renderHeader();
  renderStats();
  renderShop();
  renderUpgrades();
  renderAchievements();
  renderBoost();
  renderGemShop();
  checkAchievements();
  save();
  updateAdsVisibility();

  // İlk girişte tutorial göster
  if (!G.tutorialDone) {
    setTimeout(showTutorial, 800);
  } else {
    // Daily reward kontrolü (offline modal varsa biraz bekle)
    setTimeout(checkDailyReward, offlineSec >= 15 ? 2500 : 1200);
  }
})();
