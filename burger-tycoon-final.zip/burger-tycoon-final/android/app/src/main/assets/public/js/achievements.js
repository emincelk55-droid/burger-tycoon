/* ═══════════════════════════════════════════
   achievements.js — Başarım kontrolü ve bildirim
   Burger Tycoon
   ═══════════════════════════════════════════ */
'use strict';

let _achQueue   = [];
let _achShowing = false;

// ── Tüm başarımları kontrol et ─────────────────────

function checkAchievements() {
  let changed = false;
  let newCount = 0;
  for (const a of ACHIEVEMENTS) {
    if (!G.achiev[a.id] && a.check(G)) {
      G.achiev[a.id] = true;
      _achQueue.push(a);
      changed = true;
      newCount++;
    }
  }
  if (changed) {
    // Her başarım açıldığında 1 elmas hediye (ekstra kazanç)
    if (newCount > 0) {
      G.gems = (G.gems || 0) + newCount;
      G.gemsEverEarned = (G.gemsEverEarned || 0) + newCount;
    }
    recalcMults(); // achievBonus etkilesin
    renderAchievements();
    renderHeader();
    if (!_achShowing) _showNextAch();
  }
}

// ── Genel popup ────────────────────────────────────

function showPopup(icon, name, desc) {
  _achQueue.push({ icon, name, desc });
  if (!_achShowing) _showNextAch();
}

// ── Genel bildirim (boost, event) ──────────────────

let _noticeTimer = null;
function showNotice(icon, name, desc) {
  document.getElementById('notice-icon').textContent = icon;
  document.getElementById('notice-name').textContent = name;
  document.getElementById('notice-desc').textContent = desc;
  const el = document.getElementById('notice-popup');
  el.classList.remove('show');
  void el.offsetWidth; // reflow
  el.classList.add('show');
  clearTimeout(_noticeTimer);
  _noticeTimer = setTimeout(() => el.classList.remove('show'), 2800);
}

function _showNextAch() {
  if (_achQueue.length === 0) { _achShowing = false; return; }
  _achShowing = true;

  const a = _achQueue.shift();
  document.getElementById('pop-icon').textContent = a.icon;
  document.getElementById('pop-name').textContent = a.name;
  document.getElementById('pop-desc').textContent = a.desc + ' (+1 💎)';

  const popup = document.getElementById('ach-popup');
  popup.classList.add('show');
  sndAch();
  vibe([30, 50, 30]);

  setTimeout(() => {
    popup.classList.remove('show');
    setTimeout(_showNextAch, 380);
  }, 2800);
}
