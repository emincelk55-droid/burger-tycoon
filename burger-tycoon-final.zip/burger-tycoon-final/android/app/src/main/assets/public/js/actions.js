/* ═══════════════════════════════════════════
   actions.js — Oyuncu Etkileşimleri (Satın alma, tıklama)
   Burger Tycoon
   ═══════════════════════════════════════════ */
'use strict';

// ── Yoğunluk (Frenzy) Ayarları ─────────────────────────
const FRENZY_THRESHOLD = 1000; // ms — bu süre içinde tıklarsan combo artar
const FRENZY_RATE_UP   = 1;    // saniyede combo artışı
const FRENZY_RATE_DOWN = 25;   // boştayken combo azalması

let _frenzyLastClick = 0;

/** Combo çarpanını günceller (her oyun döngüsünde çağrılır). */
function updateFrenzy(dt) {
  const now = Date.now();
  if (_frenzyLastClick > 0 && (now - _frenzyLastClick) < FRENZY_THRESHOLD) {
    G.clickFrenzy = Math.min(100, G.clickFrenzy + (FRENZY_RATE_UP * (G.boostActive ? 3 : 1)) * dt);
  } else {
    G.clickFrenzy = Math.max(0, G.clickFrenzy - FRENZY_RATE_DOWN * dt);
  }
  renderFrenzy();
}

// ── Ekipman Satın Al ──────────────────────────────────

function buyMiner(m) {
  const qty   = G.buyMode === 0 ? calcMaxBuy(m) : G.buyMode;
  if (qty <= 0) { sndError(); return; }
  const price = calcBulkPrice(m, qty);
  if (G.sat < price) { sndError(); return; }

  G.sat -= price;
  G.miners[m.id] = (G.miners[m.id] || 0) + qty;
  G.devices += qty;

  sndBuy();
  vibe(20);
  renderShop();
  renderHeader();
  renderStats();
  checkAchievements();
  save();
}

// ── Personel Satın Al ─────────────────────────────────

function buyManager(m) {
  const qty   = G.buyMode === 0 ? calcManagerMaxBuy(m) : G.buyMode;
  if (qty <= 0) { sndError(); return; }
  const price = calcManagerBulkPrice(m, qty);
  if (G.sat < price) { sndError(); return; }

  G.sat -= price;
  G.managers[m.id] = (G.managers[m.id] || 0) + qty;

  sndBuy();
  vibe(20);
  renderShop();
  renderHeader();
  renderStats();
  checkAchievements();
  save();
}

// ── Geliştirme Satın Al ───────────────────────────────

function buyUpgrade(u) {
  if (G.upgrades[u.id]) return;
  if (G.sat < u.price) { sndError(); return; }

  G.sat -= u.price;
  G.upgrades[u.id] = true;
  G.upgCount++;

  recalcMults();
  sndBuy();
  vibe(30);
  renderUpgrades();
  renderHeader();
  renderStats();
  checkAchievements();
  save();
}

// ── Elmas Geliştirmesi Satın Al ───────────────────────

function buyGemUpgrade(u) {
  if (G.gemUpgrades[u.id]) return;
  if (u.requires && !G.gemUpgrades[u.requires]) { sndError(); return; }
  if (G.gems < u.cost) { sndError(); return; }

  G.gems -= u.cost;
  G.gemUpgrades[u.id] = true;

  recalcMults();
  G.sps = calcSps();
  sndGem();
  vibe([20, 30, 20]);
  renderHeader();
  renderStats();
  renderGemShop();
  showNotice(u.icon, u.name + ' Alındı!', u.desc);
  checkAchievements();
  save();
}

// ── Ortak Tıklama İşleyicisi ──────────────────────────

/** Ekrana $ yazısı/efekt basar ve parayı ekler */
function fireClick(cx, cy, power) {
  G.sat   += power;
  G.total += power;
  const boosted = G.boostActive && Date.now() < G.boostEndsAt;
  spawnFloat(cx, cy, (boosted ? '⚡' : '') + '+' + fmt(power) + ' $');

  const coin = document.getElementById('coin');
  if (coin) {
    coin.classList.remove('clicked');
    void coin.offsetWidth; // animasyonu sıfırlamak için reflow
    coin.classList.add('clicked');
  }
}

// ── Burger Tıklaması ──────────────────────────────────

function doClick(cx, cy) {
  if (!window.lastClick) window.lastClick = 0;
  const now = Date.now();
  if (now - window.lastClick < 50) return;  // saniyede max ~20 tık
  window.lastClick = now;

  _frenzyLastClick = now;
  const base  = calcClickPow();
  const power = Math.round(base * (1 + G.clickFrenzy / 100));
  G.clicks++;
  fireClick(cx, cy, power);

  // Ses ve titreşim — tıklamada sürekli
  sndClick();
  vibe(8);

  renderHeader();
  renderStats();
  checkAchievements();
  if (G.clicks % 10 === 0) save();
}

// ── Burger Element Olayları ───────────────────────────

(function initCoinEvents() {
  const coinEl = document.getElementById('coin');
  if (!coinEl) return;

  coinEl.addEventListener('pointerdown', e => {
    e.preventDefault();
    coinEl.classList.add('clicked');
    doClick(e.clientX, e.clientY);
  });
  coinEl.addEventListener('pointerup',    () => coinEl.classList.remove('clicked'));
  coinEl.addEventListener('pointerleave', () => coinEl.classList.remove('clicked'));

  // iOS Safari için
  coinEl.addEventListener('touchend', e => e.preventDefault(), { passive: false });
})();
