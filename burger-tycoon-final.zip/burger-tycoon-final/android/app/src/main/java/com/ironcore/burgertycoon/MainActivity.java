package com.ironcore.burgertycoon;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
