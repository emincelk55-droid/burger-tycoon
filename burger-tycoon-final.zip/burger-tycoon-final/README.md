# 🍔 Burger Tycoon — v2 (Play Store Hazır)

## ✨ Bu Sürümde Eklenenler

### Yeni Özellikler
- **🎁 Günlük Ödül Sistemi** — 7 günlük döngü; her gün giriş yaparak para, elmas veya boost kazanın. Seri kırıldığında baştan başlar.
- **📚 Tutorial Modal** — Yeni oyuncular için 6 adımlı, akıcı Türkçe başlangıç rehberi (sadece ilk açılışta gösterilir).
- **🌟 Altın Burger Olayı** — Toplam $1M kazandıktan sonra her 4–8 dakikada bir spawn olur. Yakalarsan toplam servetinin %3'ü ya da 5 dakikalık SPS — hangisi büyükse — bonus düşer. **goldenCaught** istatistiği ile takip edilir.
- **🔊 Ses Efektleri** — Web Audio API ile dosyasız ses (tıklama, satın alma, hata, başarım, elmas, boost, prestij). Ayarlar panelinden açıp kapatabilirsiniz.
- **📳 Titreşim** — Mobilde haptic feedback. Ayarlar panelinden kontrol edilebilir.
- **🛒 ×10 Satın Alma Modu** — Artık ×1 → ×10 → Maks olarak döner.
- **15. Mucit "Çoklu Evren Zinciri"** — End-game için yeni miner katmanı.
- **6. Yönetici "Global Direktör"** — Daha hızlı otomatik tıklama.
- **4 yeni "Tüm Gelir" yükseltmesi** — Hem tıklama hem mucitleri etkiler.
- **4 yeni Elmas Yükseltmesi** — boost_gem2 (boost ×3), coin_gem2 (jeton ×4), all_gem & all_gem2 (kalıcı +%50/+%100 SPS).
- **6 yeni Başarım** — mgrall, gem10, gem50, gemshop1, goldstar, streak3, streak7.
- **+5 yeni haber satırı** — Türkçe ticker zenginleştirildi.

### Ekonomi & Denge
- **Erken oyun fiyatları yumuşatıldı** (hesap makinesi 18→15, akıllı telefon 130→100, vb.) — yeni oyuncular daha akıcı ilerliyor.
- **Prestij eşiği** artık ANLIK SPS yerine **toplam yaşam-boyu kazanca** dayalı. Daha kararlı, daha öngörülebilir.
- **Her başarım +1% kalıcı SPS bonusu** verir. Başarımlar artık ekonomik olarak anlamlı.
- **Her başarım +1 💎 ödül** verir.
- **Boost x2 yerine x3** olabilir (boost_gem2 alındıysa).

### Hata Düzeltmeleri
- ✅ Yöneticilerin oto-tıklaması artık doğru şekilde para üretiyor (eskiden sadece görsel efekt vardı).
- ✅ Çevrimdışı kazançlar artık yöneticilerin katkısını da içeriyor.
- ✅ VIP (reklam kaldırma) çevrimdışı kazancı 2 katına çıkarıyor.
- ✅ Elmas takas slider'ı artık state'i koruyor.
- ✅ Prestij modal'ı arka plana tıklayınca kapanıyor.
- ✅ Light theme tüm modallarda düzgün çalışıyor.
- ✅ `countSpentGems` referans hatası düzeltildi.
- ✅ Save migration v1→v2 otomatik (eski oyuncular ilerlemelerini kaybetmez).

## 📂 Dosya Yapısı

```
burger-tycoon/
├── index.html
├── css/
│   ├── base.css       (renk değişkenleri, light/dark)
│   ├── header.css
│   ├── mine.css       (tıklama alanı)
│   ├── shop.css
│   ├── panels.css     (yan panel + ayar düğmeleri)
│   ├── modals.css     (tüm modallar — daily, tutorial, prestige, vb.)
│   ├── drops.css      (düşen jetonlar, altın burger)
│   ├── gems.css       (elmas mağazası)
│   └── style.css      (boş; main.js inline stiller için ayrılmış)
└── js/
    ├── data.js          (tüm oyun verisi: minerler, yöneticiler, başarımlar, ödüller)
    ├── utils.js         (formatlar, ses, titreşim, tarih helper'ları)
    ├── state.js         (G nesnesi, save/load v2, hesaplamalar)
    ├── render.js        (DOM render: shop, mağaza, başarımlar, paneller)
    ├── actions.js       (satın alma, tıklama, takas)
    ├── achievements.js  (kontrol & ödül dağıtımı)
    └── main.js          (oyun döngüsü, modallar, event spawn, init)
```

## 🚀 Google Play Store Kapalı Test İçin Sonraki Adımlar

Bu repo bir web tabanlı oyun. Play Store'a yüklemek için TWA (Trusted Web Activity) veya Capacitor/Cordova kullanmanız gerekecek. Hızlı checklist:

### 1. PWA Manifest Ekle
Henüz `manifest.json` yok. Aşağıdakini `index.html` ile aynı dizine ekleyin:

```json
{
  "name": "Burger Tycoon",
  "short_name": "Burger",
  "description": "Burger imparatorluğunu tek tıkla kur!",
  "start_url": "./index.html",
  "display": "standalone",
  "orientation": "portrait",
  "background_color": "#1a1a2e",
  "theme_color": "#ffb347",
  "icons": [
    { "src": "icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "icon-512.png", "sizes": "512x512", "type": "image/png" }
  ]
}
```
Ve `index.html`'in `<head>`'ine: `<link rel="manifest" href="manifest.json">`

### 2. İkonlar Hazırla
- 192×192, 512×512, ve adaptive icon (foreground 432×432) — burger emoji veya logosu.
- Play Store için **feature graphic** (1024×500), **screenshot'lar** (en az 2, ideal 4–8).

### 3. Service Worker (opsiyonel ama önerilir)
Offline çalışsın diye basit bir cache stratejisi. Bunu sonradan ekleyebilirsiniz.

### 4. TWA / Bubblewrap ile APK/AAB
```bash
npm i -g @bubblewrap/cli
bubblewrap init --manifest=https://senin-domain.com/manifest.json
bubblewrap build
```
Veya: PWABuilder.com → URL gir → AAB indir.

### 5. Play Console'da
- Gizlilik politikası URL'i (oyun reklam içerdiği için zorunlu)
- "Closed testing" (kapalı test) sekmesinde tester e-mail listesi oluştur
- Sürüm yükle, açıklama yaz, ekran görüntüleri ekle.

### 6. Reklam SDK (gelecekte)
Şu an reklam **dummy** (yer tutucu). AdMob entegrasyonu için `js/main.js` içinde reklam slot fonksiyonlarını gerçek SDK çağrılarıyla değiştirin.

## 🐛 Bilinen Sınırlamalar
- Reklam sistemi henüz dummy. AdMob/IronSource entegrasyonu Play Store'a yüklemeden önce yapılmalı.
- IAP (₺25.99 reklam kaldır) yer tutucu — Google Play Billing entegrasyonu gerekli.
- PWA manifest ve service worker eklenmesi gerekiyor (yukarıdaki adımlara bakın).

## 💾 Save Sistemi
- localStorage anahtarı: `burger_tycoon_v2`
- v1 → v2 migration otomatik
- Sıfırlama: Ayarlar paneli → "Sıfırla 🧨"

İyi oyunlar! 🍔
